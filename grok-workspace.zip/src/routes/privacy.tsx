import { createFileRoute } from "@tanstack/react-router";
import { Block, Prose } from "@/components/prose";
import { pageMeta } from "@/lib/seo";

export const Route = createFileRoute("/privacy")({
  head: () =>
    pageMeta(
      "Privacy · Talash Decorations",
      "What Talash keeps to deliver a Discord gift link, and what it never asks for. No Discord password or token.",
    ),
  component: PrivacyPage,
});

function PrivacyPage() {
  return (
    <Prose title="What we keep and why." lede="Enough to deliver a gift link. Not your Discord login.">
      <Block title="Email">
        Your email is the receipt and the place the gift link is sent. It is not used as a Discord login.
      </Block>
      <Block title="Order page">
        The order link is the record of what you bought, which coin you picked, and the gift link once it
        exists.
      </Block>
      <Block title="What we don't take">
        No Discord password, no token, no access to your account. Claiming happens on discord.com, in your
        own session.
      </Block>
      <Block title="This preview">
        Cart and orders stay in this browser only. The support form does not transmit anything.
      </Block>
    </Prose>
  );
}
