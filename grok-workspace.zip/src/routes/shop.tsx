import { createFileRoute } from "@tanstack/react-router";
import { useMemo } from "react";
import { z } from "zod";
import { ProductCard } from "@/components/product-card";
import { TYPE_TABS, type CatalogSort } from "@/lib/api";
import { pageMeta } from "@/lib/seo";
import { useCatalog, useCollections } from "@/lib/queries";

const searchSchema = z.object({
  q: z.string().optional(),
  type: z.string().optional(),
  collection: z.string().optional(),
  sort: z.enum(["name", "price_asc", "price_desc", "newest"]).optional(),
  new: z.string().optional(),
  page: z.coerce.number().int().positive().optional(),
});

export const Route = createFileRoute("/shop")({
  validateSearch: (search) => {
    const parsed = searchSchema.safeParse(search);
    return parsed.success ? parsed.data : {};
  },
  head: () =>
    pageMeta(
      "Shop Discord decorations · Talash",
      "Browse avatar decorations, profile effects, nameplates, frames and bundles from the Talash store.",
    ),
  component: ShopPage,
});

function ShopPage() {
  const search = Route.useSearch();
  const navigate = Route.useNavigate();
  const page = search.page ?? 1;
  const sort = (search.sort ?? "newest") as CatalogSort;
  const newOnly = search.new === "1";
  const query = useMemo(
    () => ({
      q: search.q || undefined,
      type: search.type && search.type !== "all" ? search.type : undefined,
      collection: search.collection || undefined,
      sort,
      new: newOnly ? "1" : undefined,
      page,
      limit: 40,
    }),
    [search.q, search.type, search.collection, sort, newOnly, page],
  );
  const catalog = useCatalog(query);
  const collections = useCollections();
  const active = TYPE_TABS.find((tab) => tab.id === (search.type || "all")) ?? TYPE_TABS[0];

  function update(patch: Partial<typeof search>, resetPage = true) {
    void navigate({
      search: {
        q: search.q,
        type: search.type,
        collection: search.collection,
        sort: search.sort,
        new: search.new,
        page: resetPage ? undefined : search.page,
        ...patch,
      },
    });
  }

  const products = catalog.data?.products ?? [];
  const total = catalog.data?.total ?? 0;
  const pages = catalog.data?.pages ?? 1;

  return (
    <div className="wrap flex flex-col gap-6 py-8">
      <div>
        <h1 className="display text-4xl">Shop All</h1>
        <p className="mt-2 text-soft">
          {catalog.isPending ? "Loading the catalog…" : `${total.toLocaleString()} item${total === 1 ? "" : "s"}`}
          {search.q ? ` matching “${search.q}”` : ""}
          {active.id !== "all" ? ` · ${active.label}` : ""}
          {search.collection ? ` · ${search.collection}` : ""}. Prices come from the store. The store sets the charge.
        </p>
      </div>

      <div className="flex flex-wrap gap-2">
        {TYPE_TABS.map((tab) => (
          <button
            key={tab.id}
            type="button"
            className={`chip ${active.id === tab.id ? "chip-on" : ""}`}
            onClick={() => update({ type: tab.id === "all" ? undefined : tab.id })}
          >
            {tab.label}
          </button>
        ))}
        <button
          type="button"
          className={`chip ${newOnly ? "chip-on" : ""}`}
          aria-pressed={newOnly}
          onClick={() => update({ new: newOnly ? undefined : "1" })}
        >
          New only
        </button>
      </div>

      <div className="flex flex-col gap-3 sm:flex-row">
        <label className="flex min-w-0 flex-1 flex-col gap-1 text-sm text-muted">
          Collection
          <select
            className="field"
            value={search.collection ?? ""}
            onChange={(e) => update({ collection: e.target.value || undefined })}
          >
            <option value="">All collections</option>
            {(collections.data ?? []).map((collection) => (
              <option key={collection.slug} value={collection.slug}>
                {collection.name}
                {collection.count ? ` (${collection.count})` : ""}
              </option>
            ))}
          </select>
        </label>
        <label className="flex w-full flex-col gap-1 text-sm text-muted sm:w-56">
          Sort
          <select
            className="field"
            value={sort}
            onChange={(e) => update({ sort: e.target.value as CatalogSort })}
          >
            <option value="newest">Newest</option>
            <option value="price_asc">Price: low to high</option>
            <option value="price_desc">Price: high to low</option>
            <option value="name">Name</option>
          </select>
        </label>
      </div>

      {catalog.isError ? (
        <div className="card p-8">
          <p className="text-danger">{catalog.error instanceof Error ? catalog.error.message : "Could not load the shop."}</p>
          <button type="button" className="btn btn-secondary mt-4" onClick={() => void catalog.refetch()}>
            Retry
          </button>
        </div>
      ) : catalog.isPending ? (
        <p className="text-muted">Loading decorations…</p>
      ) : products.length === 0 ? (
        <div className="card p-8 text-soft">Nothing matched those filters.</div>
      ) : (
        <>
          <div className="grid-cards">
            {products.map((product) => (
              <ProductCard key={product.sku_id} product={product} />
            ))}
          </div>
          {pages > 1 ? (
            <div className="flex items-center justify-center gap-3">
              <button
                type="button"
                className="btn btn-secondary"
                disabled={page <= 1}
                onClick={() => update({ page: page - 1 }, false)}
              >
                Previous
              </button>
              <span className="text-sm text-muted">
                Page {page} of {pages}
              </span>
              <button
                type="button"
                className="btn btn-secondary"
                disabled={page >= pages}
                onClick={() => update({ page: page + 1 }, false)}
              >
                Next
              </button>
            </div>
          ) : null}
        </>
      )}
    </div>
  );
}
