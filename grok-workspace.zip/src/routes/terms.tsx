import { createFileRoute } from "@tanstack/react-router";
import { Block, Prose } from "@/components/prose";
import { pageMeta } from "@/lib/seo";

export const Route = createFileRoute("/terms")({
  head: () =>
    pageMeta(
      "Terms · Talash Decorations",
      "Terms for buying Discord decorations at Talash. Gift links, claim window, and what the shop does not ask for.",
    ),
  component: TermsPage,
});

function TermsPage() {
  return (
    <Prose title="The rules, in plain words." lede="What you're agreeing to when you check out.">
      <Block title="What you are buying">
        An official Discord gift link for a shop item, not a Discord account, Nitro subscription, or login.
        You claim it yourself.
      </Block>
      <Block title="Your Discord account">
        We never ask for a password or token. Don't send one. Anyone who does is not this shop.
      </Block>
      <Block title="Prices">
        The price on the card is what you pay us, before the network fee of the coin you pick. Discord's
        crossed-out price is their listed shop price for comparison.
      </Block>
      <Block title="This preview">
        The storefront you are using does not take payment and does not create real Discord gifts.
      </Block>
      <Block title="Discord">
        Not affiliated with or endorsed by Discord Inc. Item names and art belong to their owners.
      </Block>
    </Prose>
  );
}
