import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Check, Copy } from "lucide-react";
import { useEffect, useState } from "react";
import { Logo } from "@/components/logo";
import {
  ApiError,
  cancelOrder,
  downloadReceipt,
  fetchDelivery,
  fetchInvoice,
  fetchOrder,
  type ApiPayment,
  type GiftLink,
} from "@/lib/api";
import { useDiscordAuth } from "@/lib/discord-auth";
import { formatCents, formatCountdown, formatWhen, isCompletedOrder, isTerminalOrder, orderStatusView } from "@/lib/format";
import { pageMeta } from "@/lib/seo";

export const Route = createFileRoute("/order/$id")({
  head: ({ params }) =>
    pageMeta(`Order ${params.id} · Talash Decorations`, `Order ${params.id}: payment, queue, and gift links.`, false),
  component: OrderPage,
});

const steps = ["Awaiting payment", "Confirming", "Processing", "Completed"];

function OrderPage() {
  const { id } = Route.useParams();
  const { user, loading: authLoading, login } = useDiscordAuth();
  const client = useQueryClient();
  const [copied, setCopied] = useState<string | null>(null);
  const [now, setNow] = useState(() => Date.now());
  const [cancelError, setCancelError] = useState("");
  const [cancelling, setCancelling] = useState(false);
  const [receiptError, setReceiptError] = useState("");

  const orderQuery = useQuery({
    queryKey: ["order", id],
    queryFn: () => fetchOrder(id),
    enabled: !authLoading,
    refetchInterval: (query) => {
      const status = query.state.data?.status;
      if (!status || isTerminalOrder(status)) return false;
      return 8_000;
    },
  });

  const order = orderQuery.data;
  const waiting = order?.status.toLowerCase() === "awaiting_payment";
  const needsInvoice = Boolean(order && waiting && order.pay_with !== "balance" && !order.payment?.address);

  const invoiceQuery = useQuery({
    queryKey: ["order", id, "invoice"],
    queryFn: () => fetchInvoice(id),
    enabled: needsInvoice,
    refetchInterval: waiting ? 8_000 : false,
  });

  const deliveryQuery = useQuery({
    queryKey: ["order", id, "delivery"],
    queryFn: () => fetchDelivery(id),
    enabled: Boolean(order && isCompletedOrder(order.status)),
  });

  useEffect(() => {
    const timer = window.setInterval(() => setNow(Date.now()), 1000);
    return () => window.clearInterval(timer);
  }, []);

  if (authLoading || orderQuery.isPending) {
    return <div className="wrap py-16 text-muted">Loading order…</div>;
  }

  if (orderQuery.isError || !order) {
    const status = orderQuery.error instanceof ApiError ? orderQuery.error.status : 0;
    return (
      <div className="wrap py-16">
        <h1 className="display text-4xl">{status === 404 ? "Order not found" : "Order unavailable"}</h1>
        <p className="mt-2 text-soft">
          {status === 401
            ? "Log in with Discord to view this order."
            : orderQuery.error instanceof Error
              ? orderQuery.error.message
              : "Could not load this order."}
        </p>
        <div className="mt-6 flex flex-wrap gap-3">
          {status === 401 ? (
            <button type="button" className="btn btn-primary" onClick={() => login()}>
              Login with Discord
            </button>
          ) : null}
          <Link to="/account" className="btn btn-secondary">
            Your orders
          </Link>
        </div>
      </div>
    );
  }

  const meta = orderStatusView(order.status);
  const payment: ApiPayment | null = order.payment?.address || order.payment?.payment_uri ? order.payment : invoiceQuery.data ?? order.payment ?? null;
  const showPay = waiting && order.pay_with !== "balance" && payment;
  const expiresAt = payment?.expires_at ? new Date(payment.expires_at).getTime() : null;
  const remaining = expiresAt ? Math.max(0, expiresAt - now) : null;
  const gifts: GiftLink[] = deliveryQuery.data ?? [];
  const qr = payment?.payment_uri
    ? `https://api.qrserver.com/v1/create-qr-code/?size=220x220&data=${encodeURIComponent(payment.payment_uri)}`
    : null;

  async function onCancel() {
    setCancelError("");
    setCancelling(true);
    try {
      const next = await cancelOrder(id);
      client.setQueryData(["order", id], next);
      void client.invalidateQueries({ queryKey: ["orders"] });
      void client.invalidateQueries({ queryKey: ["balance"] });
    } catch (err) {
      setCancelError(err instanceof Error ? err.message : "Could not cancel this order.");
    } finally {
      setCancelling(false);
    }
  }

  async function onReceipt() {
    setReceiptError("");
    try {
      await downloadReceipt(id);
    } catch (err) {
      setReceiptError(err instanceof Error ? err.message : "Could not download the receipt.");
    }
  }

  function copy(key: string, value: string) {
    void navigator.clipboard.writeText(value);
    setCopied(key);
    window.setTimeout(() => setCopied(null), 2000);
  }

  return (
    <div className="wrap py-8">
      <article className="invoice">
        <header className="flex items-start justify-between gap-4">
          <div className="flex items-center gap-3">
            <Logo size={40} />
            <div>
              <p className="text-xs font-semibold tracking-[0.16em] text-muted uppercase">Talash</p>
              <h1 className="display text-3xl sm:text-4xl">Order</h1>
            </div>
          </div>
          <span className={`status-pill ${meta.className}`}>{meta.label}</span>
        </header>

        <p className="text-soft">{noteFor(order.status, order.pay_with)}</p>

        <dl className="card grid grid-cols-2 gap-4 p-4 text-sm sm:grid-cols-3">
          <Meta label="Order" value={order.order_id} />
          <Meta label="Status" value={meta.label} />
          <Meta
            label="Total"
            value={order.total_cents != null ? formatCents(order.total_cents, order.currency) : "—"}
          />
          {order.pay_with ? <Meta label="Paid with" value={order.pay_with === "ltc" ? "Litecoin" : order.pay_with} /> : null}
          {order.created_at ? <Meta label="Placed" value={formatWhen(order.created_at)} /> : null}
          {order.queue_position != null ? <Meta label="Queue" value={`#${order.queue_position}`} /> : null}
          {user ? <Meta label="Account" value={user.global_name || user.username} /> : null}
        </dl>

        <ol className="grid grid-cols-2 gap-2 sm:grid-cols-4">
          {steps.map((label, index) => {
            const done = meta.step >= 0 && index <= meta.step;
            return (
              <li key={label} className={`card px-3 py-3 text-center text-sm ${done ? "text-fg" : "text-muted"}`}>
                <span className={`mb-1 block text-xs font-bold ${done ? "text-lavender-text" : ""}`}>0{index + 1}</span>
                {label}
              </li>
            );
          })}
        </ol>

        {showPay && payment ? (
          <section className="card p-4">
            <h2 className="text-sm font-semibold tracking-wide text-muted uppercase">Pay with Litecoin</h2>
            {payment.amount_ltc ? (
              <p className="mt-2 text-2xl font-bold tabular-nums">
                {payment.amount_ltc} <span className="text-base font-semibold text-muted">LTC</span>
              </p>
            ) : null}
            {remaining != null ? (
              <p className={`mt-1 text-sm ${remaining === 0 ? "text-danger" : "text-soft"}`}>
                {remaining === 0 ? "Invoice expired" : `Expires in ${formatCountdown(remaining)}`}
              </p>
            ) : null}
            {qr ? (
              <div className="mt-4 flex justify-center">
                <img src={qr} alt="Payment QR code" width={220} height={220} className="rounded-xl bg-white p-2" />
              </div>
            ) : null}
            {payment.address ? (
              <CopyBlock label="Address" value={payment.address} copied={copied === "address"} onCopy={() => copy("address", payment.address || "")} />
            ) : null}
            {payment.payment_uri ? (
              <CopyBlock label="Payment URI" value={payment.payment_uri} copied={copied === "uri"} onCopy={() => copy("uri", payment.payment_uri || "")} />
            ) : null}
            {payment.confirmations != null ? (
              <p className="mt-3 text-sm text-muted">Confirmations: {payment.confirmations}</p>
            ) : null}
          </section>
        ) : null}

        {isCompletedOrder(order.status) ? (
          <section className="card p-4">
            <h2 className="text-sm font-semibold tracking-wide text-muted uppercase">Gift links</h2>
            {deliveryQuery.isPending ? <p className="mt-2 text-sm text-muted">Loading delivery…</p> : null}
            {deliveryQuery.isError ? (
              <p className="mt-2 text-sm text-danger">
                {deliveryQuery.error instanceof Error ? deliveryQuery.error.message : "Delivery is not ready."}
              </p>
            ) : null}
            {gifts.length === 0 && !deliveryQuery.isPending && !deliveryQuery.isError ? (
              <p className="mt-2 text-sm text-muted">No gift link yet. This page refreshes until delivery is attached.</p>
            ) : null}
            <ul className="mt-3 flex flex-col gap-2">
              {gifts.map((gift) => (
                <li key={gift.url} className="copy-box">
                  <span className="min-w-0">
                    <span className="block truncate text-sm">{gift.name || gift.url}</span>
                    {gift.name ? <span className="block truncate text-xs text-muted">{gift.url}</span> : null}
                  </span>
                  <button type="button" className="btn btn-secondary h-9 shrink-0 px-3" onClick={() => copy(gift.url, gift.url)}>
                    {copied === gift.url ? <Check className="size-4" /> : <Copy className="size-4" />}
                    {copied === gift.url ? "Copied" : "Copy"}
                  </button>
                </li>
              ))}
            </ul>
          </section>
        ) : null}

        <section className="card overflow-hidden">
          <ul>
            {order.items.map((item) => (
              <li key={`${item.sku_id}-${item.name}`} className="flex items-center gap-3 border-b border-line px-4 py-3 last:border-0">
                {item.image_url ? (
                  <img src={item.image_url} alt="" className="size-14 shrink-0 rounded-xl object-contain" referrerPolicy="no-referrer" />
                ) : (
                  <span className="card-art size-14 shrink-0 rounded-xl" />
                )}
                <span className="min-w-0 flex-1">
                  <Link to="/p/$slug" params={{ slug: item.sku_id }} className="block truncate font-semibold hover:underline">
                    {item.name}
                  </Link>
                  <span className="text-sm text-muted">SKU {item.sku_id}</span>
                  {item.status ? <span className="mt-0.5 block text-xs text-muted capitalize">{item.status}</span> : null}
                  {item.queue_position != null ? (
                    <span className="mt-0.5 block text-xs text-muted">Queue #{item.queue_position}</span>
                  ) : null}
                </span>
              </li>
            ))}
          </ul>
        </section>

        <div className="flex flex-wrap gap-3">
          <button type="button" className="btn btn-secondary" onClick={() => void onReceipt()}>
            Download receipt
          </button>
          {waiting ? (
            <button type="button" className="btn btn-ghost" disabled={cancelling} onClick={() => void onCancel()}>
              {cancelling ? "Cancelling…" : "Cancel order"}
            </button>
          ) : null}
        </div>
        {cancelError ? <p className="text-sm text-danger">{cancelError}</p> : null}
        {receiptError ? <p className="text-sm text-danger">{receiptError}</p> : null}

        <footer className="flex flex-wrap gap-x-4 gap-y-2 text-sm text-muted">
          <Link to="/shop" search={{}} className="hover:text-fg">
            Shop
          </Link>
          <Link to="/account" className="hover:text-fg">
            Orders
          </Link>
          <Link to="/support" className="hover:text-fg">
            Support
          </Link>
        </footer>
      </article>
    </div>
  );
}

function noteFor(status: string, payWith?: string) {
  const s = status.toLowerCase();
  if (s === "awaiting_payment") {
    return payWith === "balance"
      ? "This order is still waiting. If the balance debit did not go through, it can be cancelled."
      : "Send the exact Litecoin amount before the invoice expires.";
  }
  if (s === "confirming") return "Payment spotted. Waiting for the network to confirm.";
  if (s === "queued" || s === "processing" || s === "buying") return "The store is buying this from Discord and will attach the gift link here.";
  if (isCompletedOrder(s)) return "Delivered. Copy the gift link, open it in Discord, and tap Claim.";
  if (s === "expired") return "This invoice expired. Place a new order if you still want these items.";
  if (s === "cancelled" || s === "canceled") return "This order was cancelled before payment.";
  return "Order status from the store.";
}

function Meta({ label, value }: { label: string; value: string }) {
  return (
    <div className="min-w-0">
      <dt className="text-xs text-muted">{label}</dt>
      <dd className="truncate font-semibold capitalize">{value}</dd>
    </div>
  );
}

function CopyBlock({
  label,
  value,
  copied,
  onCopy,
}: {
  label: string;
  value: string;
  copied: boolean;
  onCopy: () => void;
}) {
  return (
    <div className="mt-4">
      <p className="text-xs font-semibold tracking-wide text-muted uppercase">{label}</p>
      <div className="copy-box mt-1">
        <span className="truncate text-sm">{value}</span>
        <button type="button" className="btn btn-secondary h-9 shrink-0 px-3" onClick={onCopy}>
          {copied ? <Check className="size-4" /> : <Copy className="size-4" />}
          {copied ? "Copied" : "Copy"}
        </button>
      </div>
    </div>
  );
}
