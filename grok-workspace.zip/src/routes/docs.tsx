import { createFileRoute } from "@tanstack/react-router";
import { Block, Prose } from "@/components/prose";
import { pageMeta } from "@/lib/seo";

export const Route = createFileRoute("/docs")({
  head: () =>
    pageMeta(
      "Reseller API · Talash Decorations",
      "API notes for Talash reseller accounts. How orders, catalog items, and gift delivery are described.",
    ),
  component: DocsPage,
});

function DocsPage() {
  return (
    <Prose
      title="Reseller API"
      lede="A sketch of how a reseller account would place an order. No key is issued from this preview."
    >
      <Block title="Create an order">
        <pre className="mt-3 overflow-x-auto rounded-xl bg-input p-4 font-mono text-sm text-soft">{`POST /v1/orders
Authorization: Bearer <key>

{
  "email": "buyer@email.com",
  "items": [{ "sku": "bloodweb-avatar-decoration", "qty": 1 }]
}`}</pre>
      </Block>
      <Block title="What comes back">
        <pre className="mt-3 overflow-x-auto rounded-xl bg-input p-4 font-mono text-sm text-soft">{`{
  "id": "CC-1F3A9C",
  "status": "awaiting_payment",
  "total": "2.12",
  "currency": "USD"
}`}</pre>
      </Block>
      <Block title="Gift link">
        When status is <span className="font-mono text-fg">ready</span>, the order includes a
        discord.com/gifts URL. It expires 48 hours after it is issued and works once.
      </Block>
    </Prose>
  );
}
