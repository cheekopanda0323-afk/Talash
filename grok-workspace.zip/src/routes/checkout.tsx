import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { ApiError, createOrder, newIdempotencyKey, type PayWith } from "@/lib/api";
import { useDiscordAuth } from "@/lib/discord-auth";
import { formatCents } from "@/lib/format";
import { useBalance, useProducts } from "@/lib/queries";
import { pageMeta } from "@/lib/seo";
import { cartSkuIds, useCart } from "@/lib/store";
import { useQueryClient } from "@tanstack/react-query";

export const Route = createFileRoute("/checkout")({
  head: () =>
    pageMeta(
      "Checkout · Talash Decorations",
      "Pay for Discord decorations with your Talash balance or Litecoin.",
      false,
    ),
  component: CheckoutPage,
});

function CheckoutPage() {
  const lines = useCart((s) => s.lines);
  const clear = useCart((s) => s.clear);
  const navigate = useNavigate();
  const client = useQueryClient();
  const { user, loading: authLoading, login } = useDiscordAuth();
  const balance = useBalance();
  const products = useProducts(lines.map((line) => line.sku_id));
  const [payWith, setPayWith] = useState<PayWith>("ltc");
  const [error, setError] = useState("");
  const [submitting, setSubmitting] = useState(false);

  const skuIds = cartSkuIds(lines);
  const known = products.map((query) => query.data).filter((product) => product != null);
  const pendingPrices = products.some((query) => query.isPending);
  const estimatedCents = known.reduce((sum, product) => sum + product.price_cents, 0);
  const currency = known[0]?.currency || balance.data?.currency || "USD";
  const balanceCents = balance.data?.balance_cents ?? 0;
  const pricedAll = !pendingPrices && known.length === lines.length && lines.length > 0;
  const shortfall = Math.max(0, estimatedCents - balanceCents);
  const balanceShort = pricedAll && shortfall > 0;

  useEffect(() => {
    if (balanceShort && payWith === "balance") setPayWith("ltc");
  }, [balanceShort, payWith]);

  async function placeOrder() {
    setError("");
    if (authLoading) return;
    if (!user) {
      login();
      return;
    }
    if (skuIds.length === 0) {
      setError("Your cart is empty.");
      return;
    }
    if (payWith === "balance" && balanceShort) {
      setError("Insufficient balance");
      return;
    }
    setSubmitting(true);
    try {
      const order = await createOrder({
        sku_ids: skuIds,
        pay_with: payWith,
        idempotencyKey: newIdempotencyKey(),
      });
      clear();
      void client.invalidateQueries({ queryKey: ["balance"] });
      void client.invalidateQueries({ queryKey: ["orders"] });
      void client.invalidateQueries({ queryKey: ["ledger"] });
      void navigate({ to: "/order/$id", params: { id: order.order_id } });
    } catch (err) {
      if (err instanceof ApiError && err.status === 401) {
        setError("Please log in with Discord to place an order.");
        login();
      } else if (err instanceof ApiError && err.status === 402) {
        setError("Insufficient balance");
        void balance.refetch();
      } else {
        setError(err instanceof Error ? err.message : "Something went wrong. Please try again.");
      }
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div className="wrap grid gap-8 py-8 lg:grid-cols-[1fr_20rem]">
      <form
        onSubmit={(e) => {
          e.preventDefault();
          void placeOrder();
        }}
        className="flex flex-col gap-5"
      >
        <div>
          <h1 className="display text-4xl">Checkout</h1>
          <p className="mt-2 max-w-xl text-soft">
            Choose balance or Litecoin. The store prices the order itself. Nothing on this page is sent as a total.
          </p>
        </div>

        {authLoading ? (
          <p className="text-sm text-muted">Checking login…</p>
        ) : !user ? (
          <div className="card flex flex-col gap-3 p-4">
            <p className="text-sm text-soft">Log in with Discord before placing an order.</p>
            <button type="button" className="btn btn-primary" onClick={() => login()}>
              Login with Discord
            </button>
          </div>
        ) : (
          <p className="text-sm text-soft">
            Logged in as <span className="font-semibold text-fg">{user.global_name || user.username}</span>
            {balance.data ? ` · balance ${formatCents(balance.data.balance_cents, balance.data.currency)}` : ""}
          </p>
        )}

        <fieldset>
          <legend className="text-sm font-semibold">Pay with</legend>
          <div className="mt-2 grid gap-2 sm:grid-cols-2">
            <label
              className={`card flex cursor-pointer items-start justify-between gap-3 px-3 py-3 ${payWith === "balance" ? "ring-2 ring-lavender" : ""} ${balanceShort ? "opacity-70" : ""}`}
            >
              <span>
                <span className="block font-semibold">Pay with balance</span>
                <span className="text-xs text-muted">
                  {balance.isPending && user
                    ? "Loading balance…"
                    : balance.data
                      ? formatCents(balance.data.balance_cents, balance.data.currency)
                      : "Login required"}
                </span>
                {balanceShort ? (
                  <span className="mt-1 block text-xs text-danger">
                    Short {formatCents(shortfall, currency)}.{" "}
                    <Link to="/account" hash="topup" className="underline">
                      Top up
                    </Link>
                  </span>
                ) : null}
              </span>
              <input
                type="radio"
                name="pay"
                className="mt-1 size-4 accent-lavender"
                checked={payWith === "balance"}
                disabled={balanceShort}
                onChange={() => setPayWith("balance")}
              />
            </label>
            <label className={`card flex cursor-pointer items-start justify-between gap-3 px-3 py-3 ${payWith === "ltc" ? "ring-2 ring-lavender" : ""}`}>
              <span>
                <span className="block font-semibold">Pay with Litecoin</span>
                <span className="text-xs text-muted">LTC invoice on the next screen</span>
              </span>
              <input
                type="radio"
                name="pay"
                className="mt-1 size-4 accent-lavender"
                checked={payWith === "ltc"}
                onChange={() => setPayWith("ltc")}
              />
            </label>
          </div>
        </fieldset>

        {error ? <p className="text-sm text-danger">{error}</p> : null}

        <button type="submit" className="btn btn-primary btn-lg" disabled={skuIds.length === 0 || submitting || authLoading}>
          {submitting ? "Placing order…" : payWith === "balance" ? "Pay with balance" : "Pay with Litecoin"}
        </button>
        <p className="text-xs text-muted">
          Balance orders are queued immediately when the ledger can cover them. Litecoin orders stay unpaid until the
          invoice is settled. You can cancel an unpaid invoice from the order page.
        </p>
      </form>

      <aside className="card h-fit p-5">
        <h2 className="font-semibold">Your order</h2>
        {lines.length === 0 ? (
          <p className="mt-3 text-sm text-muted">
            Nothing here.{" "}
            <Link to="/shop" search={{}} className="text-lavender-text underline">
              Shop the catalog
            </Link>
          </p>
        ) : (
          <ul className="mt-3 flex flex-col gap-2 text-sm">
            {lines.map((line, index) => {
              const product = products[index]?.data;
              return (
                <li key={line.sku_id} className="flex justify-between gap-3">
                  <span className={`truncate ${product && !product.available ? "text-muted line-through" : ""}`}>
                    {product?.name || line.sku_id}
                    {product && !product.available ? " (unavailable)" : ""}
                  </span>
                  <span className="tabular-nums">
                    {product ? formatCents(product.price_cents, product.currency) : "—"}
                  </span>
                </li>
              );
            })}
          </ul>
        )}
        <div className="mt-4 flex justify-between border-t border-line pt-3">
          <span>Estimated</span>
          <span className="text-lg font-bold tabular-nums">
            {pendingPrices && lines.length > 0 ? "…" : formatCents(estimatedCents, currency)}
          </span>
        </div>
        <p className="mt-2 text-xs text-muted">Shown for reference. Not sent with the order.</p>
      </aside>
    </div>
  );
}
