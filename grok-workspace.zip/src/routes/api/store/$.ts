import { createFileRoute } from "@tanstack/react-router";

const UPSTREAMS = ["https://api.talash.store", "http://api.talash.store"];

function upstreamPath(request: Request) {
  const url = new URL(request.url);
  const path = url.pathname.replace(/^\/api\/store/, "") || "/";
  return `${path}${url.search}`;
}

async function forward(base: string, path: string, request: Request, body: ArrayBuffer | undefined) {
  const headers = new Headers();
  for (const name of ["accept", "content-type", "cookie", "idempotency-key"]) {
    const value = request.headers.get(name);
    if (value) headers.set(name, value);
  }
  return fetch(`${base}${path}`, {
    method: request.method,
    headers,
    body,
    redirect: "manual",
  });
}

function toResponse(upstream: Response, body: ArrayBuffer) {
  const headers = new Headers();
  const type = upstream.headers.get("content-type");
  if (type) headers.set("content-type", type);
  const location = upstream.headers.get("location");
  if (location) headers.set("location", location);
  const response = new Response(body, { status: upstream.status, headers });
  const cookies = upstream.headers.getSetCookie?.() ?? [];
  for (const cookie of cookies) response.headers.append("set-cookie", cookie);
  return response;
}

async function proxy(request: Request) {
  const path = upstreamPath(request);
  const body =
    request.method === "GET" || request.method === "HEAD" ? undefined : await request.arrayBuffer();
  let saw525 = false;
  for (const base of UPSTREAMS) {
    try {
      const upstream = await forward(base, path, request, body);
      if (upstream.status === 525) {
        saw525 = true;
        continue;
      }
      if (request.method === "GET" && barePath(path) === "/api/me" && upstream.status === 401) {
        return Response.json({ user: null });
      }
      if (
        request.method === "GET" &&
        (upstream.status === 404 || upstream.status === 405 || upstream.status === 501) &&
        base === UPSTREAMS[UPSTREAMS.length - 1]
      ) {
        const filled = await fillMissing(path);
        if (filled) return filled;
      }
      if (
        request.method === "GET" &&
        (upstream.status === 404 || upstream.status === 405 || upstream.status === 501) &&
        base !== UPSTREAMS[UPSTREAMS.length - 1]
      ) {
        continue;
      }
      const payload = await upstream.arrayBuffer();
      return toResponse(upstream, payload);
    } catch {
      continue;
    }
  }
  if (request.method === "GET") {
    const filled = await fillMissing(path);
    if (filled) return filled;
  }
  return Response.json(
    { error: saw525 ? "Store API TLS is unavailable." : "Store API unreachable.", code: "upstream" },
    { status: 502 },
  );
}

function barePath(path: string) {
  return path.split("?")[0] || "/";
}

async function fillMissing(path: string): Promise<Response | null> {
  const bare = barePath(path);
  if (bare === "/api/catalog" || bare.startsWith("/api/catalog/")) {
    const sku = bare.startsWith("/api/catalog/") ? decodeURIComponent(bare.slice("/api/catalog/".length)) : "";
    const products = await fetch(`${UPSTREAMS[1]}/api/products`).catch(() => null);
    if (!products?.ok) return null;
    if (!sku) return new Response(products.body, { status: 200, headers: { "content-type": "application/json" } });
    const data = (await products.json()) as { products?: Array<{ sku_id?: string }> };
    const found = data.products?.find((item) => item.sku_id === sku);
    if (!found) return Response.json({ error: "Not found.", code: "not_found" }, { status: 200 });
    return Response.json(found);
  }
  if (bare === "/api/collections") return Response.json({ collections: [] });
  if (bare === "/api/queue" || bare === "/api/stats" || bare === "/api/prices") {
    return Response.json({ supported: false });
  }
  return null;
}

export const Route = createFileRoute("/api/store/$")({
  server: {
    handlers: {
      GET: ({ request }) => proxy(request),
      POST: ({ request }) => proxy(request),
    },
  },
});
