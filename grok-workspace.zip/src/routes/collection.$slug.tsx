import { createFileRoute, Link } from "@tanstack/react-router";
import { ProductCard } from "@/components/product-card";
import { useCatalog, useCollections } from "@/lib/queries";
import { pageMeta, titleFromSlug } from "@/lib/seo";

export const Route = createFileRoute("/collection/$slug")({
  head: ({ params }) => {
    const name = titleFromSlug(params.slug);
    return pageMeta(
      `${name} collection · Talash Decorations`,
      `Shop the ${name} Discord decoration collection at Talash.`,
    );
  },
  component: CollectionPage,
});

function CollectionPage() {
  const { slug } = Route.useParams();
  const collections = useCollections();
  const catalog = useCatalog({ collection: slug, limit: 60, sort: "newest" });
  const known = collections.data?.find((collection) => collection.slug === slug);
  const name = known?.name || titleFromSlug(slug);
  const products = catalog.data?.products ?? [];

  if ((collections.isPending || catalog.isPending) && products.length === 0) {
    return (
      <div className="wrap py-16">
        <h1 className="display text-4xl">Loading this collection…</h1>
        <p className="mt-2 text-soft">Pulling it from the store.</p>
      </div>
    );
  }

  if (!catalog.isPending && products.length === 0 && !known) {
    return (
      <div className="wrap py-16">
        <h1 className="display text-4xl">Collection not found</h1>
        <p className="mt-2 text-soft">That collection is not in the current catalog.</p>
        <Link to="/shop" search={{}} className="btn btn-primary mt-6">
          Shop All
        </Link>
      </div>
    );
  }

  return (
    <div className="flex flex-col gap-8 pb-10">
      <section className="wrap pt-8">
        <div className="relative min-h-56 overflow-hidden rounded-3xl bg-card">
          {known?.banner ? (
            <img src={known.banner} alt="" className="absolute inset-0 h-full w-full object-cover" referrerPolicy="no-referrer" />
          ) : null}
          <div className="absolute inset-0 bg-gradient-to-t from-input via-input/50 to-input/10" />
          <div className="relative flex min-h-56 flex-col justify-end p-6 sm:p-8">
            <p className="text-sm font-semibold text-soft">Collection</p>
            <h1 className="display text-4xl">{name}</h1>
            <p className="mt-1 text-soft">{catalog.data?.total ?? products.length} items</p>
          </div>
        </div>
      </section>
      {catalog.isError ? (
        <div className="wrap">
          <p className="text-danger">{catalog.error instanceof Error ? catalog.error.message : "Could not load items."}</p>
        </div>
      ) : (
        <div className="wrap grid-cards">
          {products.map((product) => (
            <ProductCard key={product.sku_id} product={product} />
          ))}
        </div>
      )}
    </div>
  );
}
