import { createFileRoute, Link } from "@tanstack/react-router";
import { Block, Prose } from "@/components/prose";
import { pageMeta } from "@/lib/seo";

export const Route = createFileRoute("/how-it-works")({
  head: () =>
    pageMeta(
      "How it works · Talash Decorations",
      "From checkout to a claimed Discord gift. How Talash buys official shop items and emails the gift link.",
    ),
  component: HowPage,
});

const steps = [
  {
    n: "1",
    title: "Pick your item",
    body: "Browse it like you would in Discord. Every card shows our price right next to Discord's, so you know exactly what you're saving.",
  },
  {
    n: "2",
    title: "Pay with crypto",
    body: "Litecoin (recommended) or other crypto. Network fees are shown before you pay, not after.",
  },
  {
    n: "3",
    title: "Claim your gift link",
    body: "We buy the item and email you an official Discord gift link, usually within a few minutes. Open it, tap Claim, and it's yours.",
  },
];

function HowPage() {
  return (
    <Prose
      title="Three steps. Then it's on your profile."
      lede="You pick an item, pay with crypto, and get an official Discord gift link. Here's what happens in between."
    >
      <ol className="grid gap-3">
        {steps.map((s) => (
          <li key={s.n} className="card flex gap-4 p-5">
            <span className="display grid size-10 shrink-0 place-items-center rounded-xl bg-lavender text-lg text-white">
              {s.n}
            </span>
            <span>
              <span className="block text-lg font-semibold text-fg">{s.title}</span>
              <span className="mt-1 block text-soft">{s.body}</span>
            </span>
          </li>
        ))}
      </ol>
      <Block title="Where the items come from">
        Discord prices the same shop item differently from country to country. The shop buys each item in
        Discord's own shop through its regional pricing, legally, then sends it as a gift. Nothing is
        generated, cracked or shared.
      </Block>
      <Block title="What you get">
        An official discord.com/gifts link, by email and on your order page. Open it while logged in to
        Discord and tap Claim. The item lands in your collectibles like any gift from a friend.
      </Block>
      <Block title="How long it takes">
        After the crypto payment confirms on the blockchain, the system buys the item. Most orders are done
        within a few minutes. The order page shows each step as it happens.
      </Block>
      <Block title="Paying">
        Payments run through a crypto processor. You pick Litecoin or Other crypto on the payment page.
        Litecoin is best for small orders thanks to low fees.
      </Block>
      <Link to="/shop" search={{}} className="btn btn-primary w-fit">
        Shop the catalog
      </Link>
    </Prose>
  );
}
