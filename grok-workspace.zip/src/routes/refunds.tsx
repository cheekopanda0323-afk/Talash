import { createFileRoute } from "@tanstack/react-router";
import { Block, Prose } from "@/components/prose";
import { pageMeta } from "@/lib/seo";

export const Route = createFileRoute("/refunds")({
  head: () =>
    pageMeta(
      "Refunds · Talash Decorations",
      "What happens if Talash cannot deliver a Discord gift link. Retries, store credit, and where to look on your invoice.",
    ),
  component: RefundsPage,
});

function RefundsPage() {
  return (
    <Prose title="If we can't deliver" lede="The short version of what happens when a gift link doesn't go out.">
      <Block title="We retry first">
        If the Discord Shop rejects the purchase, the order is retried. Your order page stays on the buying
        step until it clears or a person takes it.
      </Block>
      <Block title="Then a person">
        If it still fails, you get the gift or the payment back as store credit. Crypto that already moved
        is not reversed on-chain; credit is how the difference is settled.
      </Block>
      <Block title="Underpaid invoices">
        A payment within 2% of the invoice still counts. Further off, support emails the address on the
        order.
      </Block>
      <Block title="Claim window">
        Discord gift links expire. Claim within 48 hours of the email. A link that expired because it sat
        unclaimed is not refunded.
      </Block>
    </Prose>
  );
}
