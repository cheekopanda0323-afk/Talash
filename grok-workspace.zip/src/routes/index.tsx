import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { ArrowRight, Gift, Shuffle, Star, Wallet, Zap } from "lucide-react";
import { useState, type FormEvent, type ReactNode } from "react";
import { ProductArt, ProductCard } from "@/components/product-card";
import { fetchCatalog, type StoreCollection, type StoreProduct } from "@/lib/api";
import { formatCents } from "@/lib/format";
import { useCatalog, useCollections, useQueue } from "@/lib/queries";
import { pageMeta } from "@/lib/seo";
import { useCart } from "@/lib/store";

export const Route = createFileRoute("/")({
  head: () =>
    pageMeta(
      "Talash Decorations · Discord Shop items for less",
      "Avatar decorations, profile effects, nameplates, frames and bundles. Pay with balance or Litecoin. Official gift links.",
    ),
  component: Home,
});

const reviews = [
  {
    name: "The***",
    text: "Bought 6x items. Legit website",
    date: "Oct 24, 2026",
    stars: 5,
    bought: "Dark Moon",
  },
  {
    name: "NRZ.",
    text: "Great services, Fast and Trusted",
    date: "Oct 24, 2026",
    stars: 5,
    bought: "Trapped Souls",
  },
  {
    name: "! Mr Ghost",
    text: "WOW! Instant and fast delivery. Delivered in literally 3 minutes.",
    date: "Oct 23, 2026",
    stars: 4,
    bought: "Butterfly Waltz",
  },
];

function Home() {
  const navigate = useNavigate();
  const add = useCart((s) => s.add);
  const catalog = useCatalog({ sort: "newest", limit: 12, page: 1 });
  const collections = useCollections();
  const queue = useQueue();
  const featured = (collections.data ?? []).slice(0, 3);
  const products = catalog.data?.products ?? [];
  const hero = products.slice(0, 8);
  const loop = hero.length > 0 ? [...hero, ...hero] : [];
  const sample = products[0];
  const maxSave = products.reduce((n, product) => Math.max(n, product.save_percent ?? 0), 0);
  const [paste, setPaste] = useState("");
  const [pasteMsg, setPasteMsg] = useState("");
  const [pasteBusy, setPasteBusy] = useState(false);

  async function onPaste(e: FormEvent) {
    e.preventDefault();
    const raw = paste.trim();
    if (!raw) {
      setPasteMsg("Paste a Discord shop link or item name.");
      return;
    }
    const skuMatch = raw.match(/itemSkuId[=:](\d+)/i) || raw.match(/(\d{15,})/);
    const q = skuMatch ? skuMatch[1] : raw.replace(/^https?:\/\/(www\.)?discord\.com\/shop\/?/i, "").trim();
    setPasteBusy(true);
    try {
      const hits = await fetchCatalog({ q, limit: 5 });
      const best = hits.products[0];
      if (!best) {
        setPasteMsg("Nothing matched. Try the item name or browse the shop.");
        return;
      }
      add(best.sku_id, best.name);
      setPasteMsg(`Added ${best.name} · ${formatCents(best.price_cents, best.currency)}`);
      setPaste("");
    } catch (err) {
      setPasteMsg(err instanceof Error ? err.message : "Search failed.");
    } finally {
      setPasteBusy(false);
    }
  }

  async function onRandom() {
    try {
      const page = await fetchCatalog({ limit: 40, sort: "newest" });
      if (page.products.length === 0) return;
      const pick = page.products[Math.floor(Math.random() * page.products.length)];
      add(pick.sku_id, pick.name);
      void navigate({ to: "/cart" });
    } catch {
      setPasteMsg("Could not pick a random item. The shop may be offline.");
    }
  }

  return (
    <div className="flex flex-col gap-16 pb-8">
      <section className="wrap grid items-center gap-10 py-10 lg:grid-cols-[1.05fr_0.95fr] lg:py-16">
        <div className="rise flex flex-col gap-5">
          <h1 className="display text-4xl leading-tight sm:text-5xl lg:text-6xl">
            Every Discord Shop item.
            <span className="block text-lavender-text">
              {maxSave > 0 ? `Up to ${maxSave}% cheaper.` : "For less than the shop price."}
            </span>
          </h1>
          <p className="max-w-xl text-lg text-soft">
            Decorations, effects, nameplates, frames and bundles, delivered as official Discord gift links. Pay with
            your Talash balance or Litecoin.
          </p>
          <div className="flex flex-wrap gap-3">
            <Link to="/shop" search={{}} className="btn btn-primary btn-lg">
              Shop All
            </Link>
            <Link to="/how-it-works" className="btn btn-secondary btn-lg">
              How it works
            </Link>
          </div>
          <p className="font-mono text-sm text-muted">
            {sample
              ? sample.compare_at_cents && sample.compare_at_cents > sample.price_cents
                ? `${formatCents(sample.compare_at_cents, sample.currency)} list, ${formatCents(sample.price_cents, sample.currency)} here`
                : formatCents(sample.price_cents, sample.currency)
              : catalog.isError
                ? "Shop is offline right now"
                : "Official gift links"}
          </p>
        </div>

        <div className="grid gap-3 sm:grid-cols-[1.15fr_0.85fr]">
          <div className="card flex flex-col gap-4 p-4">
            <div className="flex items-center justify-between text-xs text-muted">
              <span>How it works</span>
              <span className="font-mono">Live catalog</span>
            </div>
            {sample ? (
              <div className="card-art relative overflow-hidden rounded-xl">
                <ProductArt product={sample} eager className="aspect-art" />
              </div>
            ) : (
              <div className="card-art aspect-art rounded-xl" />
            )}
            <div>
              <p className="text-sm text-muted">{sample?.type_label || "Decoration"} in the Discord Shop</p>
              <div className="mt-1 flex items-center gap-2">
                {sample?.compare_at_cents && sample.compare_at_cents > sample.price_cents ? (
                  <s className="text-muted">{formatCents(sample.compare_at_cents, sample.currency)}</s>
                ) : null}
                <span className="text-2xl font-bold tabular-nums">
                  {sample ? formatCents(sample.price_cents, sample.currency) : ""}
                </span>
                {sample?.save_percent ? <span className="pill-save">-{sample.save_percent}%</span> : null}
              </div>
            </div>
            <div className="rounded-xl bg-input p-3">
              <p className="text-sm font-semibold">Your gift is ready. Enjoy!</p>
              <p className="text-xs text-muted">You've been gifted a decoration</p>
              <div className="btn btn-save mt-3 h-9 w-full">Claimed</div>
            </div>
          </div>

          <div className="relative hidden max-h-[34rem] overflow-hidden sm:block" aria-hidden>
            <div className="marquee-y grid gap-2.5">
              {loop.map((product, index) => (
                <div key={`${product.sku_id}-${index}`} className="flex flex-col gap-2 rounded-2xl bg-card p-2">
                  <ProductArt product={product} className="aspect-video rounded-xl" />
                  <div className="flex items-center gap-2 px-1 pb-1">
                    <span className="truncate text-sm font-semibold">{product.name}</span>
                    <span className="ml-auto text-sm font-bold tabular-nums">
                      {formatCents(product.price_cents, product.currency)}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className="wrap">
        <div className="card grid gap-4 p-5 md:grid-cols-[1.4fr_auto] md:items-end">
          <div className="flex flex-col gap-3">
            <div className="flex flex-wrap items-center gap-2">
              <span className="rounded-full bg-lavender/20 px-2.5 py-0.5 text-xs font-semibold text-lavender-text">
                {queue.data && !queue.isError ? queue.data.label : "Queue"}
              </span>
              <span className="text-xs text-muted">Paste a Discord shop link or item name</span>
            </div>
            <form onSubmit={(e) => void onPaste(e)} className="flex flex-col gap-2 sm:flex-row">
              <input
                type="text"
                value={paste}
                onChange={(e) => {
                  setPaste(e.target.value);
                  setPasteMsg("");
                }}
                placeholder="https://discord.com/shop#itemSkuId=… or item name"
                className="field flex-1"
              />
              <div className="flex gap-2">
                <button type="submit" className="btn btn-primary" disabled={pasteBusy}>
                  {pasteBusy ? "Looking…" : "Get price"}
                </button>
                <button type="button" onClick={() => void onRandom()} className="btn btn-secondary inline-flex items-center gap-1.5">
                  <Shuffle className="size-4" />
                  Random
                </button>
              </div>
            </form>
            {pasteMsg ? <p className="text-sm text-lavender-text">{pasteMsg}</p> : null}
          </div>
          <p className="text-sm text-muted md:max-w-[14rem] md:text-right">
            Official gift links · balance or Litecoin
          </p>
        </div>
      </section>

      <section className="wrap flex flex-col gap-6">
        <div>
          <p className="text-sm font-semibold text-lavender-text">Why Talash</p>
          <h2 className="display mt-1 text-3xl sm:text-4xl">Real items, real gift links, real fast</h2>
          <p className="mt-2 max-w-2xl text-soft">
            The catalog, balance, and orders all come from the Talash store. This site does not keep its own prices.
          </p>
        </div>
        <div className="grid gap-3 md:grid-cols-3">
          <Feature
            icon={<Gift className="size-5" />}
            title="Official Discord gift links"
            body="When the order completes, the gift link shows on the order page. Open it, tap Claim, and it lands on your profile."
          />
          <Feature
            icon={<Wallet className="size-5" />}
            title="Balance or Litecoin"
            body="Top up with Litecoin, then pay from your balance. Or pay that order in Litecoin directly. The store decides the amount."
          />
          <Feature
            icon={<Zap className="size-5" />}
            title="Watch the order move"
            body="Awaiting payment, confirming, processing, completed. Cancel while it is still unpaid. Download the receipt any time."
          />
        </div>
      </section>

      {catalog.isError ? (
        <section className="wrap">
          <div className="card p-6">
            <p className="text-danger">{catalog.error instanceof Error ? catalog.error.message : "The catalog is offline."}</p>
            <button type="button" className="btn btn-secondary mt-4" onClick={() => void catalog.refetch()}>
              Retry
            </button>
          </div>
        </section>
      ) : null}

      {featured.length > 0 ? (
        <section className="wrap grid gap-3 md:grid-cols-3">
          {featured.map((collection) => (
            <CollectionTile key={collection.slug} collection={collection} />
          ))}
        </section>
      ) : null}

      <section className="wrap flex flex-col gap-5">
        <div>
          <h2 className="display text-3xl">Newest in the shop</h2>
          <p className="mt-1 text-muted">Fresh from the store catalog.</p>
        </div>
        {catalog.isPending ? (
          <p className="text-muted">Loading decorations…</p>
        ) : (
          <div className="grid-cards">
            {products.slice(0, 10).map((product, index) => (
              <ProductCard key={product.sku_id} product={product} eager={index < 4} />
            ))}
          </div>
        )}
      </section>

      {featured.map((collection) => (
        <CollectionStrip key={collection.slug} collection={collection} />
      ))}

      <section className="wrap flex flex-col gap-5">
        <div className="flex flex-wrap items-end justify-between gap-4">
          <div>
            <h2 className="display text-3xl">What buyers say</h2>
            <p className="mt-1 text-soft">4.7 based on 3 reviews</p>
          </div>
          <Link to="/reviews" className="text-sm font-semibold text-lavender-text hover:underline">
            Read all reviews
          </Link>
        </div>
        <div className="grid gap-3 md:grid-cols-3">
          {reviews.map((review) => (
            <article key={review.name} className="card flex flex-col gap-3 p-5">
              <div className="flex items-center justify-between">
                <Stars n={review.stars} />
                <span className="text-xs text-muted">{review.date}</span>
              </div>
              <p className="text-soft">{review.text}</p>
              <p className="mt-auto text-sm font-semibold">{review.name}</p>
              <p className="text-xs text-ok">Verified buyer · {review.bought}</p>
            </article>
          ))}
        </div>
      </section>

      <section className="wrap">
        <div className="card flex flex-col items-start gap-4 p-8 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h2 className="display text-3xl">There's so much more</h2>
            <p className="mt-1.5 text-soft">Browse by type, collection, or name. New items are marked in the shop.</p>
          </div>
          <Link to="/shop" search={{}} className="btn btn-primary btn-lg">
            Shop All
          </Link>
        </div>
      </section>
    </div>
  );
}

function CollectionTile({ collection }: { collection: StoreCollection }) {
  return (
    <Link
      to="/collection/$slug"
      params={{ slug: collection.slug }}
      className="group relative min-h-36 overflow-hidden rounded-2xl bg-card"
    >
      {collection.banner ? (
        <img
          src={collection.banner}
          alt=""
          className="absolute inset-0 h-full w-full object-cover transition-transform duration-300 group-hover:scale-[1.02]"
          referrerPolicy="no-referrer"
        />
      ) : null}
      <div className="absolute inset-0 bg-gradient-to-t from-input via-input/40 to-transparent" />
      <div className="relative flex h-full min-h-36 flex-col justify-end p-4">
        <span className="text-lg font-semibold">{collection.name}</span>
        <span className="text-sm text-soft">{collection.count ? `${collection.count} items` : "Collection"}</span>
      </div>
    </Link>
  );
}

function CollectionStrip({ collection }: { collection: StoreCollection }) {
  const catalog = useCatalog({ collection: collection.slug, limit: 8, sort: "newest" });
  const products: StoreProduct[] = catalog.data?.products ?? [];
  if (!catalog.isPending && products.length === 0) return null;
  return (
    <section className="wrap flex flex-col gap-5" aria-label={collection.name}>
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h2 className="display text-3xl">{collection.name}</h2>
          <p className="mt-1 text-muted">{collection.count ? `${collection.count} items` : "From the store"}</p>
        </div>
        <Link to="/collection/$slug" params={{ slug: collection.slug }} className="btn btn-ghost">
          Shop the collection
          <ArrowRight className="size-4" />
        </Link>
      </div>
      {catalog.isPending ? (
        <p className="text-muted">Loading…</p>
      ) : (
        <div className="grid-cards">
          {products.map((product) => (
            <ProductCard key={product.sku_id} product={product} />
          ))}
        </div>
      )}
    </section>
  );
}

function Feature({ icon, title, body }: { icon: ReactNode; title: string; body: string }) {
  return (
    <article className="card flex flex-col gap-3 p-5">
      <span className="grid size-10 place-items-center rounded-xl bg-input text-lavender-text">{icon}</span>
      <h3 className="text-lg font-semibold">{title}</h3>
      <p className="text-sm leading-relaxed text-soft">{body}</p>
    </article>
  );
}

function Stars({ n }: { n: number }) {
  return (
    <span className="inline-flex gap-0.5 text-warn" aria-label={`${n} out of 5`}>
      {Array.from({ length: 5 }, (_, i) => (
        <Star key={i} className={`size-4 ${i < n ? "fill-current" : "text-muted"}`} strokeWidth={0} />
      ))}
    </span>
  );
}
