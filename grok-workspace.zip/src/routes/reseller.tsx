import { createFileRoute, Link } from "@tanstack/react-router";
import { Block, Prose } from "@/components/prose";
import { pageMeta } from "@/lib/seo";

export const Route = createFileRoute("/reseller")({
  head: () =>
    pageMeta(
      "Reseller · Talash Decorations",
      "Bulk Discord decoration pricing, priority queue, and API access for resellers. Litecoin and other crypto accepted.",
    ),
  component: ResellerPage,
});

function ResellerPage() {
  return (
    <Prose
      title="Sell Discord decorations without the Discord price."
      lede="Reseller accounts get lower unit prices, a shared catalog, and an API so you can fulfill orders from your own store or Discord server."
    >
      <div className="grid gap-3 sm:grid-cols-3">
        <div className="card p-5">
          <p className="text-sm font-semibold text-lavender-text">Starter</p>
          <p className="mt-1 display text-3xl">5% off</p>
          <p className="mt-2 text-sm text-soft">For people moving a few dozen gifts a month. Same checkout, lower numbers on the invoice.</p>
        </div>
        <div className="card p-5 ring-2 ring-lavender">
          <p className="text-sm font-semibold text-lavender-text">Growth</p>
          <p className="mt-1 display text-3xl">12% off</p>
          <p className="mt-2 text-sm text-soft">Priority queue, dedicated support channel, and access to the order API. Best for servers and small shops.</p>
        </div>
        <div className="card p-5">
          <p className="text-sm font-semibold text-lavender-text">Volume</p>
          <p className="mt-1 display text-3xl">Custom</p>
          <p className="mt-2 text-sm text-soft">Hundreds of gifts per day. Talk to us about dedicated stock and private pricing.</p>
        </div>
      </div>

      <Block title="What you get">
        <ul className="mt-2 list-disc space-y-1 pl-5 text-soft">
          <li>Lower prices on every catalog item</li>
          <li>Priority fulfillment when the queue is busy</li>
          <li>API keys for placing orders and reading gift links (see <Link to="/docs" className="text-lavender-text underline">API docs</Link>)</li>
          <li>Payment in Litecoin or other crypto</li>
          <li>No Discord login required from your buyers — they still get official gift links</li>
        </ul>
      </Block>

      <Block title="How to start">
        Join the Discord, open a ticket, and tell us your expected volume. We'll set the discount and issue an API key if you need one. This preview does not process real reseller applications.
      </Block>

      <div className="flex flex-wrap gap-3">
        <a href="https://discord.gg/talash" target="_blank" rel="noreferrer" className="btn btn-primary">
          Join Discord & apply
        </a>
        <Link to="/docs" className="btn btn-secondary">
          Read the API sketch
        </Link>
      </div>
    </Prose>
  );
}
