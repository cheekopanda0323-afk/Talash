import { createFileRoute } from "@tanstack/react-router";
import { useState, type FormEvent } from "react";
import { Block, Prose } from "@/components/prose";
import { pageMeta } from "@/lib/seo";

export const Route = createFileRoute("/support")({
  head: () =>
    pageMeta(
      "Support · Talash Decorations",
      "Questions about a Talash order or invoice. Reach the shop, or join discord.gg/talash.",
    ),
  component: SupportPage,
});

function SupportPage() {
  const [sent, setSent] = useState(false);

  function onSubmit(e: FormEvent) {
    e.preventDefault();
    setSent(true);
  }

  return (
    <Prose
      title="Talk to a person."
      lede="Order questions go to the inbox on your receipt. This preview keeps the note on screen only."
    >
      <div className="grid gap-3 sm:grid-cols-2">
        <a href="https://discord.gg/talash" target="_blank" rel="noreferrer" className="card p-5">
          <h2 className="font-semibold">Discord</h2>
          <p className="mt-1 text-sm text-muted">discord.gg/talash</p>
        </a>
        <div className="card p-5">
          <h2 className="font-semibold">Telegram</h2>
          <p className="mt-1 text-sm text-muted">Same idea. Messages here stay inside the preview.</p>
        </div>
      </div>
      <Block title="Send a note">
        {sent ? (
          <p className="text-ok">Got it. In this preview nothing is forwarded.</p>
        ) : (
          <form onSubmit={onSubmit} className="mt-2 flex flex-col gap-3">
            <input className="field" required placeholder="Email" type="email" aria-label="Email" />
            <input className="field" placeholder="Order id, if you have one" aria-label="Order id" />
            <textarea
              required
              className="field h-32 py-3"
              placeholder="What happened?"
              aria-label="Message"
            />
            <button type="submit" className="btn btn-primary w-fit">
              Send
            </button>
          </form>
        )}
      </Block>
    </Prose>
  );
}
