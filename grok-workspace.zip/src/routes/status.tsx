import { createFileRoute } from "@tanstack/react-router";
import { useHealth, useQueue, useStats } from "@/lib/queries";
import { pageMeta } from "@/lib/seo";

export const Route = createFileRoute("/status")({
  head: () =>
    pageMeta(
      "Status · Talash Decorations",
      "Live queue, catalog health, and payment status for the Talash store.",
    ),
  component: StatusPage,
});

function StatusPage() {
  const health = useHealth();
  const queue = useQueue();
  const stats = useStats();
  const healthy = health.data?.ok !== false && !health.isError;
  const queueDepth = queue.data?.depth ?? stats.data?.queue;

  const systems = [
    {
      name: "Store API",
      state: health.isPending ? "Checking" : healthy ? "Operational" : "Unavailable",
      detail: health.data?.service
        ? `${health.data.service}${health.data.catalog_items != null ? ` · ${health.data.catalog_items} catalog items` : ""}`
        : health.isError
          ? health.error instanceof Error
            ? health.error.message
            : "Health check failed"
          : "Asking the store",
    },
    {
      name: "Discord",
      state: health.data?.discord_ready == null ? "Unknown" : health.data.discord_ready ? "Operational" : "Degraded",
      detail: health.data?.discord_ready ? "The store can reach Discord" : "Reported by /api/health",
    },
    {
      name: "Payments",
      state: health.data?.payments_ready == null ? "Unknown" : health.data.payments_ready ? "Operational" : "Degraded",
      detail: "Balance ledger and Litecoin invoices",
    },
    {
      name: "Order queue",
      state: queue.isError ? "Unknown" : queueDepth == null ? "Checking" : queueDepth === 0 ? "Clear" : `${queueDepth} waiting`,
      detail: queue.data?.label || (queue.isError ? "Queue endpoint did not answer" : "Public queue depth"),
    },
  ];

  return (
    <div className="wrap flex flex-col gap-8 py-10">
      <div>
        <p className="text-sm font-semibold text-lavender-text">System status</p>
        <h1 className="display mt-1 text-4xl">{healthy ? "Store is up" : health.isPending ? "Checking the store" : "Store is having trouble"}</h1>
        <p className="mt-2 max-w-xl text-soft">
          Public health, queue, and stats from the Talash API. Nothing here is estimated locally.
        </p>
      </div>

      <div className="grid gap-3 sm:grid-cols-2">
        {systems.map((system) => (
          <div key={system.name} className="card flex flex-col gap-1 p-5">
            <div className="flex items-center justify-between gap-3">
              <span className="font-semibold">{system.name}</span>
              <span className={`status-pill ${pillClass(system.state)}`}>{system.state}</span>
            </div>
            <p className="text-sm text-muted">{system.detail}</p>
          </div>
        ))}
      </div>

      {stats.data && (stats.data.orders != null || stats.data.delivered != null) ? (
        <div className="card grid gap-4 p-5 sm:grid-cols-3">
          <Stat label="Orders" value={stats.data.orders} />
          <Stat label="Delivered" value={stats.data.delivered} />
          <Stat label="Catalog" value={stats.data.catalog_items ?? health.data?.catalog_items} />
        </div>
      ) : null}

      <div className="card p-5">
        <h2 className="font-semibold">How the queue works</h2>
        <p className="mt-2 text-sm text-soft">
          Balance orders are queued as soon as the ledger debit succeeds. Litecoin orders join after the invoice
          confirms. Your order page shows the status and, when the store sends it, a queue position. Gift links appear
          there when the order is completed.
        </p>
      </div>
    </div>
  );
}

function pillClass(state: string) {
  if (state === "Operational" || state === "Clear") return "status-done";
  if (state === "Unavailable" || state === "Degraded") return "status-pending";
  return "status-processing";
}

function Stat({ label, value }: { label: string; value?: number }) {
  return (
    <div>
      <p className="text-xs text-muted">{label}</p>
      <p className="text-2xl font-bold tabular-nums">{value != null ? value.toLocaleString() : "—"}</p>
    </div>
  );
}
