import { createFileRoute, Link } from "@tanstack/react-router";
import { Trash2 } from "lucide-react";
import { ProductArt } from "@/components/product-card";
import { formatCents } from "@/lib/format";
import { useProducts } from "@/lib/queries";
import { pageMeta } from "@/lib/seo";
import { useCart } from "@/lib/store";

export const Route = createFileRoute("/cart")({
  head: () =>
    pageMeta("Cart · Talash Decorations", "Review Discord decorations before checkout. The store confirms the total.", false),
  component: CartPage,
});

function CartPage() {
  const lines = useCart((s) => s.lines);
  const remove = useCart((s) => s.remove);
  const products = useProducts(lines.map((line) => line.sku_id));
  const pending = products.some((query) => query.isPending);
  const priced = products.filter((query) => query.data);
  const cents = priced.reduce((sum, query) => sum + (query.data?.price_cents ?? 0), 0);
  const currency = priced[0]?.data?.currency || "USD";

  return (
    <div className="wrap grid gap-8 py-8 lg:grid-cols-[1fr_20rem]">
      <div>
        <h1 className="display text-4xl">Cart</h1>
        {lines.length === 0 ? (
          <div className="card mt-6 p-8">
            <p className="text-soft">Your cart is empty.</p>
            <Link to="/shop" search={{}} className="btn btn-primary mt-4">
              Shop All
            </Link>
          </div>
        ) : (
          <ul className="mt-6 flex flex-col gap-3">
            {lines.map((line, index) => {
              const product = products[index]?.data;
              const failed = products[index]?.isError;
              return (
                <li key={line.sku_id} className="card flex gap-3 p-3">
                  <Link to="/p/$slug" params={{ slug: line.sku_id }} className="shrink-0">
                    {product ? (
                      <ProductArt product={product} className="size-20 rounded-xl" />
                    ) : (
                      <span className="card-art block size-20 rounded-xl" />
                    )}
                  </Link>
                  <div className="min-w-0 flex-1">
                    <Link to="/p/$slug" params={{ slug: line.sku_id }} className="font-semibold hover:underline">
                      {product?.name || (products[index]?.isPending ? "Loading…" : "Item")}
                    </Link>
                    <p className="text-sm text-muted">{product?.type_label || line.sku_id}</p>
                    {product && !product.available ? <p className="mt-1 text-xs text-danger">Currently unavailable</p> : null}
                    {failed ? <p className="mt-1 text-xs text-danger">Could not load this item.</p> : null}
                    <p className="mt-1 font-bold tabular-nums">
                      {product ? formatCents(product.price_cents, product.currency) : "—"}
                    </p>
                    <button
                      type="button"
                      className="mt-2 grid size-11 place-items-center rounded-lg text-muted hover:text-danger"
                      aria-label={`Remove ${product?.name || "item"}`}
                      onClick={() => remove(line.sku_id)}
                    >
                      <Trash2 className="size-4" />
                    </button>
                  </div>
                </li>
              );
            })}
          </ul>
        )}
      </div>
      <aside className="card h-fit p-5">
        <h2 className="text-lg font-semibold">Summary</h2>
        <div className="mt-4 flex items-center justify-between">
          <span className="text-muted">Estimated</span>
          <span className="text-xl font-bold tabular-nums">{pending ? "…" : formatCents(cents, currency)}</span>
        </div>
        <p className="mt-2 text-xs text-muted">
          Each decoration is quantity 1. This estimate is not the charge. The store recomputes it when you pay with
          balance or Litecoin.
        </p>
        <Link
          to="/checkout"
          className={`btn btn-primary btn-lg mt-4 w-full ${lines.length === 0 ? "pointer-events-none opacity-50" : ""}`}
          aria-disabled={lines.length === 0}
        >
          Checkout
        </Link>
      </aside>
    </div>
  );
}
