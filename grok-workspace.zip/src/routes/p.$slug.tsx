import { createFileRoute, Link } from "@tanstack/react-router";
import { Clock, Gift, Shield } from "lucide-react";
import { ProductArt, ProductCard } from "@/components/product-card";
import { ApiError } from "@/lib/api";
import { formatCents } from "@/lib/format";
import { useCatalog, useCatalogItem } from "@/lib/queries";
import { pageMeta } from "@/lib/seo";
import { useCart } from "@/lib/store";

export const Route = createFileRoute("/p/$slug")({
  head: ({ params }) =>
    pageMeta(
      `Decoration ${params.slug} · Talash`,
      "Discord decoration from the Talash store. Official gift link after the store confirms payment.",
    ),
  component: ProductPage,
});

function ProductPage() {
  const { slug } = Route.useParams();
  const productQuery = useCatalogItem(slug);
  const product = productQuery.data;
  const related = useCatalog(
    {
      type: product?.type,
      collection: product?.collection_slug || undefined,
      limit: 8,
    },
    Boolean(product),
  );
  const add = useCart((s) => s.add);

  if (productQuery.isPending) {
    return (
      <div className="wrap py-16">
        <h1 className="display text-4xl">Loading this decoration…</h1>
        <p className="mt-2 text-soft">Fetching it from the store.</p>
      </div>
    );
  }

  if (productQuery.isError || !product) {
    const missing = productQuery.error instanceof ApiError && productQuery.error.status === 404;
    return (
      <div className="wrap py-16">
        <h1 className="display text-4xl">{missing ? "Item not in the catalog" : "Could not load this item"}</h1>
        <p className="mt-2 text-soft">
          {missing
            ? "It may have left the shop, or the link is off."
            : productQuery.error instanceof Error
              ? productQuery.error.message
              : "Try again in a moment."}
        </p>
        <Link to="/shop" search={{}} className="btn btn-primary mt-6">
          Back to the shop
        </Link>
      </div>
    );
  }

  const price = formatCents(product.price_cents, product.currency);
  const compare =
    product.compare_at_cents != null && product.compare_at_cents > product.price_cents
      ? formatCents(product.compare_at_cents, product.currency)
      : null;
  const more = (related.data?.products ?? []).filter((item) => item.sku_id !== product.sku_id).slice(0, 8);

  return (
    <div className="wrap flex flex-col gap-12 py-8">
      <div className="grid items-start gap-8 lg:grid-cols-2">
        <div className="card overflow-hidden">
          <ProductArt product={product} eager stage="bare" className="aspect-square" />
        </div>
        <div className="flex flex-col gap-4">
          {product.collection_slug && product.collection_name ? (
            <Link
              to="/collection/$slug"
              params={{ slug: product.collection_slug }}
              className="text-sm font-semibold text-lavender-text"
            >
              {product.collection_name}
            </Link>
          ) : (
            <span className="text-sm text-muted">{product.type_label}</span>
          )}
          <h1 className="display text-4xl">{product.name}</h1>
          <p className="text-muted">{product.type_label}</p>
          <div className="flex flex-wrap items-center gap-3">
            <span className="text-3xl font-bold tabular-nums">{price}</span>
            {compare ? <s className="text-lg text-muted">{compare}</s> : null}
            {product.save_percent != null && product.save_percent > 0 ? (
              <span className="pill-save">Save {product.save_percent}%</span>
            ) : null}
            {product.is_new ? <span className="status-pill status-processing">New</span> : null}
          </div>
          <p className="max-w-xl text-soft">
            {product.name} from the Discord Shop, sent as an official gift link after the store confirms payment. We
            never need your Discord password or token. The price you see is from the catalog. The store recomputes the
            total at checkout.
          </p>
          <ul className="flex flex-col gap-2 text-sm text-soft">
            <li className="flex items-center gap-2">
              <Gift className="size-4 text-lavender-text" /> Official gift link on the order page when it is done
            </li>
            <li className="flex items-center gap-2">
              <Clock className="size-4 text-lavender-text" /> Pay with balance, or Litecoin if you would rather
            </li>
            <li className="flex items-center gap-2">
              <Shield className="size-4 text-lavender-text" /> Availability: {product.availability}
            </li>
          </ul>
          <p className="text-sm text-muted">SKU {product.sku_id}</p>
          <div className="flex flex-wrap gap-3 pt-2">
            {product.available ? (
              <button type="button" className="btn btn-primary btn-lg" onClick={() => add(product.sku_id, product.name)}>
                Add to cart
              </button>
            ) : (
              <button type="button" className="btn btn-primary btn-lg" disabled>
                Unavailable
              </button>
            )}
            <Link to="/cart" className="btn btn-ghost btn-lg">
              Go to cart
            </Link>
          </div>
        </div>
      </div>
      {more.length > 0 ? (
        <section className="flex flex-col gap-4">
          <h2 className="display text-2xl">More like this</h2>
          <div className="grid-cards">
            {more.map((item) => (
              <ProductCard key={item.sku_id} product={item} />
            ))}
          </div>
        </section>
      ) : null}
    </div>
  );
}
