import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { Prose } from "@/components/prose";
import { pageMeta } from "@/lib/seo";

export const Route = createFileRoute("/faq")({
  head: () =>
    pageMeta(
      "FAQ · Talash Decorations",
      "Why Talash is cheaper, how official Discord gift links work, which coins you can pay with, and what happens if delivery fails.",
    ),
  component: FaqPage,
});

const faqs = [
  [
    "Why is it this cheap?",
    "Discord charges a different price for the same item in different countries. The shop buys through Discord's regional pricing, legally, and passes most of the difference on. Same item, same official gift link, a lot less money.",
  ],
  [
    "Is this legit?",
    "Every item is bought in Discord's own shop and sent as an official Discord gift link. You claim it inside Discord yourself. The shop never asks for your password, token or login.",
  ],
  [
    "How long does it take?",
    "Most gift links land in your inbox a few minutes after your payment confirms. If a lot of orders come in at once, your order page shows where you are in line.",
  ],
  [
    "How do I claim my gift?",
    "Open the gift link while you're logged in to Discord and tap Claim. It works once, for one account, so don't share it before you've claimed it. Claim it within 48 hours: Discord gift links expire after that.",
  ],
  [
    "Which coins can I pay with?",
    "Litecoin (recommended for low fees) or Other crypto. If you choose Other crypto, place the invoice and support will reply with a wallet address for the coin you prefer.",
  ],
  [
    "What if something goes wrong?",
    "If the item can't be bought, it's retried. If it still doesn't work, a person picks it up, and you either get your gift or your money back as store credit. Your order page always shows where things stand.",
  ],
  [
    "I paid a little less than the invoice. What now?",
    "Crypto prices move while you pay. A payment that lands within 2% of the invoice still counts as paid. If it's further off, support contacts you by email to sort it out.",
  ],
  [
    "Do I need an account?",
    "No. Your email is enough. The order page link in your email is your receipt and shows your gift links.",
  ],
  [
    "Can I trust you guys?",
    "Start with one cheap decoration and judge the order page on that. This preview does not take a real payment.",
  ],
] as const;

function FaqPage() {
  const [open, setOpen] = useState(0);
  return (
    <Prose
      title="Questions we actually get."
      lede="Short answers, no fine print games. If yours isn't here, the support page is the next stop."
    >
      <div className="flex flex-col gap-2">
        {faqs.map(([q, a], i) => {
          const on = open === i;
          return (
            <div key={q} className="card overflow-hidden">
              <button
                type="button"
                className="flex w-full items-center justify-between gap-4 px-4 py-4 text-left font-semibold"
                aria-expanded={on}
                onClick={() => setOpen(on ? -1 : i)}
              >
                {q}
                <span className="text-muted">{on ? "–" : "+"}</span>
              </button>
              {on ? <p className="px-4 pb-4 text-soft">{a}</p> : null}
            </div>
          );
        })}
      </div>
      <Link to="/support" className="btn btn-secondary w-fit">
        Still stuck? Talk to us
      </Link>
    </Prose>
  );
}
