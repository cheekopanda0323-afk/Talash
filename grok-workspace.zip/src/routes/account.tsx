import { createFileRoute, Link } from "@tanstack/react-router";
import { Check, Copy, X } from "lucide-react";
import { useEffect, useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { ApiError, createTopup, depositPhase, newIdempotencyKey, type Deposit } from "@/lib/api";
import { useDiscordAuth } from "@/lib/discord-auth";
import { formatCents, formatWhen, orderStatusView } from "@/lib/format";
import { useBalance, useDeposit, useLedger, useOrders } from "@/lib/queries";
import { pageMeta } from "@/lib/seo";

export const Route = createFileRoute("/account")({
  head: () =>
    pageMeta(
      "Account · Talash Decorations",
      "Balance, Litecoin top-ups, and orders for your Talash account.",
      false,
    ),
  component: AccountPage,
});

function AccountPage() {
  const { user, loading, login } = useDiscordAuth();
  const balance = useBalance();
  const ledger = useLedger(1);
  const orders = useOrders(1);
  const [topupOpen, setTopupOpen] = useState(false);

  useEffect(() => {
    if (typeof window !== "undefined" && window.location.hash === "#topup") setTopupOpen(true);
  }, []);

  return (
    <div className="wrap flex max-w-3xl flex-col gap-8 py-10">
      <div>
        <p className="text-sm font-semibold text-lavender-text">Customer</p>
        <h1 className="display mt-1 text-4xl">Account</h1>
        {loading ? (
          <p className="mt-3 text-lg text-soft">Checking login…</p>
        ) : !user ? (
          <>
            <p className="mt-3 text-lg text-soft">Log in with Discord to see your balance and orders.</p>
            <button type="button" className="btn btn-primary mt-6" onClick={() => login()}>
              Login with Discord
            </button>
          </>
        ) : (
          <p className="mt-3 text-lg text-soft">
            Signed in as <span className="font-semibold text-fg">{user.global_name || user.username}</span>
          </p>
        )}
      </div>

      {user ? (
        <>
          <section className="card flex flex-col gap-4 p-5 sm:flex-row sm:items-center sm:justify-between">
            <div>
              <p className="text-sm text-muted">Balance</p>
              <p className="mt-1 text-3xl font-bold tabular-nums">
                {balance.isPending ? "…" : balance.data ? formatCents(balance.data.balance_cents, balance.data.currency) : "—"}
              </p>
              {balance.isError ? (
                <p className="mt-1 text-sm text-danger">
                  {balance.error instanceof Error ? balance.error.message : "Could not load balance."}
                </p>
              ) : (
                <p className="mt-1 text-sm text-muted">Used at checkout. Top-ups are Litecoin deposits.</p>
              )}
            </div>
            <button type="button" className="btn btn-primary" onClick={() => setTopupOpen(true)}>
              Top up
            </button>
          </section>

          <section>
            <h2 className="display text-2xl">Balance history</h2>
            {ledger.isPending ? (
              <p className="mt-3 text-muted">Loading ledger…</p>
            ) : ledger.isError ? (
              <p className="mt-3 text-danger">{ledger.error instanceof Error ? ledger.error.message : "Could not load history."}</p>
            ) : ledger.data && ledger.data.entries.length === 0 ? (
              <p className="mt-3 text-muted">No balance activity yet.</p>
            ) : (
              <div className="card mt-3 overflow-x-auto">
                <table className="w-full min-w-[32rem] text-left text-sm">
                  <thead className="text-xs tracking-wide text-muted uppercase">
                    <tr>
                      <th className="px-4 py-3 font-semibold">When</th>
                      <th className="px-4 py-3 font-semibold">Type</th>
                      <th className="px-4 py-3 font-semibold">Note</th>
                      <th className="px-4 py-3 text-right font-semibold">Amount</th>
                    </tr>
                  </thead>
                  <tbody>
                    {ledger.data?.entries.map((entry) => (
                      <tr key={entry.id} className="border-t border-line">
                        <td className="px-4 py-3 whitespace-nowrap text-muted">{formatWhen(entry.created_at)}</td>
                        <td className="px-4 py-3 capitalize">{entry.type.replaceAll("_", " ")}</td>
                        <td className="px-4 py-3 text-muted">{entry.note || "—"}</td>
                        <td className={`px-4 py-3 text-right font-semibold tabular-nums ${entry.amount_cents < 0 ? "text-danger" : "text-ok"}`}>
                          {formatCents(entry.amount_cents, balance.data?.currency || "USD")}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </section>

          <section>
            <h2 className="display text-2xl">Orders</h2>
            {orders.isPending ? (
              <p className="mt-3 text-muted">Loading orders…</p>
            ) : orders.isError ? (
              <div className="card mt-3 p-6">
                <p className="text-danger">{orders.error instanceof Error ? orders.error.message : "Could not load orders."}</p>
                <button type="button" className="btn btn-secondary mt-4" onClick={() => void orders.refetch()}>
                  Retry
                </button>
              </div>
            ) : orders.data && orders.data.orders.length === 0 ? (
              <div className="card mt-3 p-6">
                <p className="text-soft">No orders yet.</p>
                <Link to="/shop" search={{}} className="btn btn-primary mt-4">
                  Shop All
                </Link>
              </div>
            ) : (
              <ul className="mt-3 flex flex-col gap-3">
                {orders.data?.orders.map((order) => {
                  const pill = orderStatusView(order.status);
                  return (
                    <li key={order.order_id}>
                      <Link to="/order/$id" params={{ id: order.order_id }} className="card flex items-center justify-between gap-3 p-4">
                        <span className="min-w-0">
                          <span className="block font-semibold">{order.order_id}</span>
                          <span className="block truncate text-sm text-muted">
                            {order.items.map((item) => item.name).join(", ") || "Order"}
                          </span>
                        </span>
                        <span className={`status-pill ${pill.className}`}>{pill.label}</span>
                        <span className="font-bold tabular-nums">
                          {order.total_cents != null ? formatCents(order.total_cents, order.currency) : "—"}
                        </span>
                      </Link>
                    </li>
                  );
                })}
              </ul>
            )}
          </section>
        </>
      ) : null}

      {topupOpen && user ? <TopupModal onClose={() => setTopupOpen(false)} /> : null}
    </div>
  );
}

function TopupModal({ onClose }: { onClose: () => void }) {
  const client = useQueryClient();
  const [amount, setAmount] = useState("10");
  const [deposit, setDeposit] = useState<Deposit | null>(null);
  const [error, setError] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [copied, setCopied] = useState<"address" | "uri" | null>(null);
  const polled = useDeposit(deposit?.deposit_id ?? null);
  const live = polled.data ?? deposit;
  const phase = live ? depositPhase(live.status) : "pending";

  useEffect(() => {
    if (phase === "credited") {
      void client.invalidateQueries({ queryKey: ["balance"] });
      void client.invalidateQueries({ queryKey: ["ledger"] });
    }
  }, [phase, client]);

  async function submit() {
    setError("");
    const value = amount.trim();
    const numeric = Number(value);
    if (!value || !Number.isFinite(numeric) || numeric <= 0) {
      setError("Enter an amount greater than zero.");
      return;
    }
    setSubmitting(true);
    try {
      const created = await createTopup(numeric, newIdempotencyKey());
      setDeposit(created);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Could not start the top-up.");
    } finally {
      setSubmitting(false);
    }
  }

  const qr = live?.payment_uri
    ? `https://api.qrserver.com/v1/create-qr-code/?size=220x220&data=${encodeURIComponent(live.payment_uri)}`
    : null;

  return (
    <div className="fixed inset-0 z-50 grid place-items-center bg-page/80 p-4 backdrop-blur-sm">
      <div className="card max-h-[90dvh] w-full max-w-lg overflow-y-auto p-5" role="dialog" aria-modal="true" aria-labelledby="topup-title">
        <div className="flex items-start justify-between gap-3">
          <div>
            <h2 id="topup-title" className="display text-2xl">
              Top up
            </h2>
            <p className="mt-1 text-sm text-muted">Send Litecoin. The store credits your balance when it confirms.</p>
          </div>
          <button type="button" className="btn btn-ghost h-11 w-11 px-0" aria-label="Close" onClick={onClose}>
            <X className="size-4" />
          </button>
        </div>

        {!live ? (
          <form
            className="mt-4 flex flex-col gap-3"
            onSubmit={(e) => {
              e.preventDefault();
              void submit();
            }}
          >
            <label className="text-sm font-semibold" htmlFor="topup-amount">
              Amount (USD)
            </label>
            <input
              id="topup-amount"
              className="field"
              inputMode="decimal"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
            />
            {error ? <p className="text-sm text-danger">{error}</p> : null}
            <button type="submit" className="btn btn-primary" disabled={submitting}>
              {submitting ? "Creating deposit…" : "Create Litecoin deposit"}
            </button>
          </form>
        ) : (
          <div className="mt-4 flex flex-col gap-3">
            <p className={`text-sm font-semibold ${phase === "credited" ? "text-ok" : phase === "failed" ? "text-danger" : "text-soft"}`}>
              {phase === "credited" ? "Credited to your balance." : phase === "failed" ? `Deposit ${live.status}.` : "Waiting for the Litecoin payment."}
            </p>
            {live.amount_ltc ? (
              <p className="text-2xl font-bold tabular-nums">
                {live.amount_ltc} <span className="text-base font-semibold text-muted">LTC</span>
              </p>
            ) : null}
            {live.expires_at ? <p className="text-sm text-muted">Expires {formatWhen(live.expires_at)}</p> : null}
            {qr ? (
              <img src={qr} alt="Litecoin payment QR code" width={220} height={220} className="rounded-xl bg-white p-2" />
            ) : null}
            {live.address ? (
              <CopyRow
                label="Address"
                value={live.address}
                copied={copied === "address"}
                onCopy={() => {
                  void navigator.clipboard.writeText(live.address || "");
                  setCopied("address");
                }}
              />
            ) : null}
            {live.payment_uri ? (
              <CopyRow
                label="Payment URI"
                value={live.payment_uri}
                copied={copied === "uri"}
                onCopy={() => {
                  void navigator.clipboard.writeText(live.payment_uri || "");
                  setCopied("uri");
                }}
              />
            ) : null}
            <p className="text-xs text-muted">Deposit {live.deposit_id}</p>
          </div>
        )}
      </div>
    </div>
  );
}

function CopyRow({
  label,
  value,
  copied,
  onCopy,
}: {
  label: string;
  value: string;
  copied: boolean;
  onCopy: () => void;
}) {
  return (
    <div>
      <p className="text-xs font-semibold tracking-wide text-muted uppercase">{label}</p>
      <div className="copy-box mt-1">
        <span className="truncate text-sm">{value}</span>
        <button type="button" className="btn btn-secondary h-9 shrink-0 px-3" onClick={onCopy}>
          {copied ? <Check className="size-4" /> : <Copy className="size-4" />}
          {copied ? "Copied" : "Copy"}
        </button>
      </div>
    </div>
  );
}
