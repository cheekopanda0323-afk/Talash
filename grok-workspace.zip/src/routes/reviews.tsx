import { createFileRoute } from "@tanstack/react-router";
import { BadgeCheck, Star } from "lucide-react";
import { Prose } from "@/components/prose";
import { pageMeta } from "@/lib/seo";

export const Route = createFileRoute("/reviews")({
  head: () =>
    pageMeta(
      "Reviews · Talash Decorations",
      "Buyer reviews for Talash Decorations. Real notes on Discord gift link speed and delivery.",
    ),
  component: ReviewsPage,
});

const reviews = [
  {
    name: "The***",
    text: "Bought 6x items. Legit website",
    date: "Oct 24, 2026",
    stars: 5,
    items: ["Dark Moon (Base)", "Dark Moon (Base)", "Dark Moon Crows (Base)"],
  },
  {
    name: "NRZ.",
    text: "Great services, Fast and Trusted",
    date: "Oct 24, 2026",
    stars: 5,
    items: ["Trapped Souls"],
  },
  {
    name: "! Mr Ghost",
    text: "WOW! Instant and fast delivery. Delivered in literally 3 minutes. Best regards.",
    date: "Oct 23, 2026",
    stars: 4,
    items: ["Butterfly Waltz"],
  },
];

function ReviewsPage() {
  return (
    <Prose title="What buyers say" lede="4.7 based on 3 reviews. Names are shortened the way the shop shows them.">
      <div className="card grid gap-4 p-5 sm:grid-cols-[10rem_1fr] sm:items-center">
        <div>
          <p className="display text-5xl">4.7</p>
          <Stars n={5} />
        </div>
        <ul className="flex flex-col gap-1 text-sm text-muted">
          <li>5 stars · 2</li>
          <li>4 stars · 1</li>
          <li>3 stars and below · 0</li>
        </ul>
      </div>
      <div className="flex flex-col gap-3">
        {reviews.map((r) => (
          <article key={r.name} className="card flex flex-col gap-3 p-5">
            <div className="flex items-center justify-between">
              <Stars n={r.stars} />
              <span className="text-xs text-muted">{r.date}</span>
            </div>
            <p className="text-soft">{r.text}</p>
            <p className="flex items-center gap-2 text-sm font-semibold">
              {r.name}
              <span className="inline-flex items-center gap-1 text-xs font-semibold text-ok">
                <BadgeCheck className="size-3.5" /> Verified buyer
              </span>
            </p>
            <p className="text-xs text-muted">Bought {r.items.join(", ")}</p>
          </article>
        ))}
      </div>
    </Prose>
  );
}

function Stars({ n }: { n: number }) {
  return (
    <span className="inline-flex gap-0.5 text-warn" aria-label={`${n} out of 5`}>
      {Array.from({ length: 5 }, (_, i) => (
        <Star key={i} className={`size-4 ${i < n ? "fill-current" : "text-muted"}`} strokeWidth={0} />
      ))}
    </span>
  );
}
