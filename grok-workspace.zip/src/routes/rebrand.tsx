import { createFileRoute, Link } from "@tanstack/react-router";
import { Block, Prose } from "@/components/prose";
import { pageMeta } from "@/lib/seo";

export const Route = createFileRoute("/rebrand")({
  head: () =>
    pageMeta(
      "Rebrand the shop · Talash Decorations",
      "Run this Discord decoration shop under your own brand. Talash sets up the store and fulfillment.",
    ),
  component: RebrandPage,
});

const steps = [
  ["Message us", "Tell us your brand name, the domain you want, and what you have in mind."],
  ["We set it up", "The store is built with your branding and connected to the fulfillment backend."],
  ["You start selling", "Point your domain at the store and share it. Orders are fulfilled automatically."],
];

function RebrandPage() {
  return (
    <Prose
      title="A Talash shop, on your domain."
      lede="Talash Decorations can run a copy of this store with your name, logo, colours and domain. It uses the same catalog sync, so every order is bought and delivered for you."
    >
      <div className="grid gap-3">
        <Block title="Your brand, your domain">
          Your store name, logo and colours on a domain you own. Customers see your brand on the site, the
          checkout and the order emails.
        </Block>
        <Block title="The full Discord Shop, kept current">
          Every decoration, effect, nameplate, frame and bundle, synced as Discord adds and removes items.
        </Block>
        <Block title="Orders handled for you">
          Purchases go through the system, which buys each item and delivers the gift link. You don't
          need phones, Discord accounts or stock.
        </Block>
        <Block title="Crypto checkout built in">
          The same crypto checkout this store uses, with live order pages that show each step.
        </Block>
      </div>
      <ol className="grid gap-3">
        {steps.map(([title, body], i) => (
          <li key={title} className="card flex gap-4 p-5">
            <span className="display text-2xl text-lavender-text">{i + 1}</span>
            <span>
              <span className="block font-semibold text-fg">{title}</span>
              <span className="text-soft">{body}</span>
            </span>
          </li>
        ))}
      </ol>
      <p className="text-soft">Pricing depends on what you need. This preview does not take brand requests.</p>
      <Link to="/support" className="btn btn-primary w-fit">
        Talk to us
      </Link>
    </Prose>
  );
}
