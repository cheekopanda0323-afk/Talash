export function Logo({ size = 30 }: { size?: number }) {
  const id = `tl-${size}`;
  return (
    <svg width={size} height={size} viewBox="0 0 64 64" aria-hidden="true">
      <defs>
        <linearGradient id={id} x1="8" y1="4" x2="56" y2="60" gradientUnits="userSpaceOnUse">
          <stop offset="0" stopColor="#c4a6ff" />
          <stop offset="0.55" stopColor="#a978ff" />
          <stop offset="1" stopColor="#6d46d4" />
        </linearGradient>
      </defs>
      <rect width="64" height="64" rx="16" fill={`url(#${id})`} />
      <circle cx="32" cy="32" r="14" fill="none" stroke="#f4f1f8" strokeWidth="4" />
      <circle cx="32" cy="32" r="6.5" fill="#f4f1f8" />
      <path d="M44 14.5l1.4 3.6 3.6 1.4-3.6 1.4-1.4 3.6-1.4-3.6-3.6-1.4 3.6-1.4z" fill="#f4f1f8" />
    </svg>
  );
}
