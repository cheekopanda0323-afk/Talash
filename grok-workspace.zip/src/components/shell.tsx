import { Link, useNavigate, useRouterState } from "@tanstack/react-router";
import { Menu, Search, ShoppingCart, Sparkles, X } from "lucide-react";
import { useEffect, useState, type FormEvent, type ReactNode } from "react";
import { Logo } from "@/components/logo";
import { discordAvatarUrl, displayName } from "@/lib/api";
import { useDiscordAuth } from "@/lib/discord-auth";
import { formatCents } from "@/lib/format";
import { useBalance, useCatalog, useQueue } from "@/lib/queries";
import { cartCount, useCart, useMotion } from "@/lib/store";

const others = [
  { to: "/how-it-works", title: "How it works", note: "From checkout to claimed gift" },
  { to: "/reviews", title: "Reviews", note: "Real buyers, real orders" },
  { to: "/faq", title: "FAQ", note: "Short answers to real questions" },
  { to: "/reseller", title: "Reseller", note: "Bulk pricing & API access" },
  { to: "/status", title: "Status", note: "Live queue & system health" },
  { to: "/support", title: "Support", note: "Questions about an order" },
  { to: "/docs", title: "API", note: "For reseller accounts" },
  { to: "/refunds", title: "Refunds", note: "What happens if we can't deliver" },
  { to: "/terms", title: "Terms", note: "The rules, in plain words" },
  { to: "/privacy", title: "Privacy", note: "What we keep and why" },
] as const;

export function Shell({ children }: { children: ReactNode }) {
  const navigate = useNavigate();
  const path = useRouterState({ select: (s) => s.location.pathname });
  const lines = useCart((s) => s.lines);
  const toast = useCart((s) => s.toast);
  const dismiss = useCart((s) => s.dismiss);
  const [query, setQuery] = useState("");
  const [debounced, setDebounced] = useState("");
  const [openSuggest, setOpenSuggest] = useState(false);
  const [othersOpen, setOthersOpen] = useState(false);
  const [mobileNav, setMobileNav] = useState(false);
  const count = cartCount(lines);
  const animate = useMotion((s) => s.animate);
  const toggleMotion = useMotion((s) => s.toggle);
  const { user, loading: authLoading, login, logout } = useDiscordAuth();
  const balance = useBalance();
  const queue = useQueue();
  const suggestions = useCatalog({ q: debounced, limit: 6 }, debounced.length > 0);

  useEffect(() => {
    void useCart.persist.rehydrate();
    void useMotion.persist.rehydrate();
  }, []);

  useEffect(() => {
    const timer = window.setTimeout(() => setDebounced(query.trim()), 180);
    return () => window.clearTimeout(timer);
  }, [query]);

  useEffect(() => {
    if (!toast) return;
    const timer = window.setTimeout(() => dismiss(), 2400);
    return () => window.clearTimeout(timer);
  }, [toast, dismiss]);

  useEffect(() => {
    setOthersOpen(false);
    setMobileNav(false);
    setOpenSuggest(false);
  }, [path]);

  function onSearch(e: FormEvent) {
    e.preventDefault();
    const q = query.trim();
    setOpenSuggest(false);
    void navigate({ to: "/shop", search: q ? { q } : {} });
  }

  const suggestRows = debounced ? (suggestions.data?.products ?? []) : [];
  const queueLabel = queue.data && !queue.isError ? queue.data.label : null;

  return (
    <div className="flex min-h-dvh flex-col">
      <a
        href="#main"
        className="sr-only focus:not-sr-only focus:absolute focus:top-2 focus:left-2 focus:z-50 focus:rounded-lg focus:bg-card focus:px-3 focus:py-2"
      >
        Skip to content
      </a>
      <header className="sticky top-0 z-30 border-b border-line bg-chrome/70 backdrop-blur-xl">
        <div className="h-0.5 bg-lavender-glow" />
        <nav className="wrap flex flex-wrap items-center gap-x-2 gap-y-2.5 py-3 lg:gap-x-4" aria-label="Main">
          <Link to="/" aria-label="Talash Decorations home" className="order-1 flex shrink-0 items-center gap-2.5">
            <Logo />
            <span className="leading-none">
              <span className="display block text-xl">Talash</span>
              <span className="block text-xs font-semibold tracking-wide text-lavender-text">Decorations</span>
            </span>
          </Link>

          <div className="order-2 ml-auto flex items-center gap-2 lg:order-4">
            <button
              type="button"
              className={`btn h-11 px-3 ${animate ? "btn-primary" : "btn-ghost"}`}
              aria-pressed={animate}
              onClick={() => toggleMotion()}
            >
              <Sparkles className="size-4" aria-hidden />
              <span className="hidden sm:inline">{animate ? "Animated" : "Animate"}</span>
              <span className="sr-only sm:hidden">{animate ? "Animations on" : "Turn animations on"}</span>
            </button>
            {!authLoading && user ? (
              <>
                <Link to="/account" className="btn btn-ghost h-11 max-w-[11rem] gap-2 px-2 text-sm">
                  {discordAvatarUrl(user, 64) ? (
                    <img
                      src={discordAvatarUrl(user, 64) as string}
                      alt=""
                      className="size-7 rounded-full object-cover"
                      referrerPolicy="no-referrer"
                    />
                  ) : (
                    <span className="grid size-7 place-items-center rounded-full bg-lavender text-xs font-bold text-white">
                      {(displayName(user)[0] || "?").toUpperCase()}
                    </span>
                  )}
                  <span className="hidden truncate sm:inline">{displayName(user)}</span>
                </Link>
                <Link to="/account" className="btn btn-ghost hidden h-11 px-3 text-sm tabular-nums md:inline-flex">
                  {balance.data ? formatCents(balance.data.balance_cents, balance.data.currency) : "Balance"}
                </Link>
                <button type="button" className="btn btn-ghost hidden h-11 px-2 text-xs text-muted sm:inline-flex" onClick={() => void logout()}>
                  Log out
                </button>
              </>
            ) : !authLoading ? (
              <button type="button" className="btn btn-secondary h-11 px-3 text-sm" onClick={() => login()}>
                Login with Discord
              </button>
            ) : null}
            <button
              type="button"
              className="btn btn-ghost h-11 w-11 px-0 lg:hidden"
              aria-expanded={mobileNav}
              aria-label={mobileNav ? "Close menu" : "Open menu"}
              onClick={() => setMobileNav((v) => !v)}
            >
              {mobileNav ? <X className="size-5" /> : <Menu className="size-5" />}
            </button>
            <Link to="/cart" aria-label={`Cart, ${count} items`} className="btn btn-ghost relative h-11 px-3">
              <ShoppingCart className="size-4" aria-hidden />
              <span className="hidden sm:inline">Cart</span>
              {count > 0 ? (
                <span className="grid min-w-5 place-items-center rounded-full bg-lavender px-1.5 text-xs font-bold text-white">
                  {count}
                </span>
              ) : null}
            </Link>
          </div>

          <div
            className={`${mobileNav ? "flex" : "hidden"} order-3 w-full flex-col gap-2 lg:order-2 lg:flex lg:w-auto lg:flex-row lg:items-center`}
          >
            <div className="flex flex-wrap gap-1">
              <Link to="/" className={`chip ${path === "/" ? "chip-on" : ""}`}>
                Featured
              </Link>
              <Link to="/shop" search={{}} className={`chip ${path === "/shop" ? "chip-on" : ""}`}>
                Shop All
              </Link>
              <Link to="/account" className={`chip ${path === "/account" ? "chip-on" : ""}`}>
                Orders
              </Link>
              <Link to="/rebrand" className={`chip ${path === "/rebrand" ? "chip-on" : ""}`}>
                Rebrand
              </Link>
              <div className="relative">
                <button
                  type="button"
                  className="chip"
                  aria-expanded={othersOpen}
                  aria-haspopup="menu"
                  onClick={() => setOthersOpen((v) => !v)}
                >
                  Others
                </button>
                {othersOpen ? (
                  <div role="menu" className="absolute top-12 left-0 z-40 w-72 rounded-2xl bg-chrome p-2 shadow-2xl ring-1 ring-line">
                    {others.map((item) => (
                      <Link key={item.to} to={item.to} role="menuitem" className="flex flex-col rounded-xl px-3 py-2 hover:bg-card">
                        <span className="text-sm font-semibold">{item.title}</span>
                        <span className="text-xs text-muted">{item.note}</span>
                      </Link>
                    ))}
                  </div>
                ) : null}
              </div>
            </div>
            {user ? (
              <button type="button" className="btn btn-ghost h-11 w-fit px-3 text-sm sm:hidden" onClick={() => void logout()}>
                Log out
              </button>
            ) : null}
          </div>

          <form role="search" onSubmit={onSearch} className="relative order-4 min-w-0 w-full lg:order-3 lg:w-72 lg:flex-1">
            <label className="sr-only" htmlFor="shop-search">
              Search the shop
            </label>
            <div className="relative flex h-11 items-center gap-2.5 rounded-lg bg-input px-3.5 ring-lavender focus-within:ring-2">
              <Search className="size-4 shrink-0 text-muted" aria-hidden />
              <input
                id="shop-search"
                value={query}
                onChange={(e) => {
                  setQuery(e.target.value);
                  setOpenSuggest(true);
                }}
                onFocus={() => setOpenSuggest(true)}
                placeholder="Search decorations"
                className="h-full w-full bg-transparent text-sm outline-none placeholder:text-muted"
                autoComplete="off"
              />
            </div>
            {openSuggest && query.trim() ? (
              <div className="absolute top-full z-40 mt-2 w-full overflow-hidden rounded-xl bg-chrome shadow-2xl ring-1 ring-line">
                {debounced.length === 0 || suggestions.isFetching ? (
                  <p className="px-3 py-3 text-sm text-muted">Searching the shop…</p>
                ) : suggestions.isError ? (
                  <p className="px-3 py-3 text-sm text-danger">
                    {suggestions.error instanceof Error ? suggestions.error.message : "Search failed."}
                  </p>
                ) : suggestRows.length === 0 ? (
                  <p className="px-3 py-3 text-sm text-muted">No matches.</p>
                ) : (
                  suggestRows.map((product) => (
                    <Link
                      key={product.sku_id}
                      to="/p/$slug"
                      params={{ slug: product.sku_id }}
                      className="flex items-center justify-between gap-3 px-3 py-2.5 hover:bg-card"
                    >
                      <span className="min-w-0">
                        <span className="block truncate text-sm font-semibold">{product.name}</span>
                        <span className="text-xs text-muted">{product.type_label}</span>
                      </span>
                      <span className="text-sm font-bold tabular-nums">
                        {formatCents(product.price_cents, product.currency)}
                      </span>
                    </Link>
                  ))
                )}
              </div>
            ) : null}
          </form>
        </nav>
        <p className="wrap pb-2 text-xs text-muted">
          {queueLabel ? `${queueLabel} · ` : ""}
          Catalog from the Talash store
          {user && balance.data ? ` · Balance ${formatCents(balance.data.balance_cents, balance.data.currency)}` : ""}
        </p>
      </header>

      <main id="main" className="flex-1">
        {children}
      </main>

      <footer className="mt-8 border-t border-line bg-chrome/80 backdrop-blur-xl">
        <div className="wrap grid gap-8 py-10 sm:grid-cols-2 lg:grid-cols-4">
          <div className="sm:col-span-2 lg:col-span-1">
            <div className="flex items-center gap-2.5">
              <Logo size={26} />
              <span className="display text-xl">Talash Decorations</span>
            </div>
            <p className="mt-3 max-w-xs text-sm text-muted">
              Discord Shop decorations for less. Pay with your Talash balance or Litecoin. Official gift links are
              delivered on the order page.
            </p>
            <a
              href="https://discord.gg/talash"
              target="_blank"
              rel="noreferrer"
              className="mt-3 inline-flex text-sm font-semibold text-lavender-text hover:underline"
            >
              discord.gg/talash
            </a>
            <p className="mt-3 text-sm text-soft">Balance or Litecoin at checkout</p>
          </div>
          <FooterCol
            title="Shop"
            links={[
              ["/", "Featured"],
              ["/shop", "Shop All"],
              ["/shop?type=0", "Avatar"],
              ["/shop?type=1", "Effects"],
              ["/shop?type=2", "Nameplates"],
              ["/shop?type=3", "Frames"],
              ["/shop?type=1000", "Bundles"],
            ]}
          />
          <FooterCol
            title="Help"
            links={[
              ["/how-it-works", "How it works"],
              ["/faq", "FAQ"],
              ["/reviews", "Reviews"],
              ["/reseller", "Reseller"],
              ["/status", "Status"],
              ["/support", "Support"],
              ["/docs", "API docs"],
              ["/rebrand", "Rebrand"],
              ["/account", "Account"],
            ]}
          />
          <FooterCol
            title="Legal"
            links={[
              ["/terms", "Terms"],
              ["/privacy", "Privacy"],
              ["/refunds", "Refunds"],
            ]}
          />
        </div>
        <div className="border-t border-line">
          <p className="wrap py-4 text-xs text-muted">
            Not affiliated with or endorsed by Discord Inc. Item names and art belong to their owners. Prices on this
            site are shown from the store API. The store confirms the amount when you pay.
          </p>
        </div>
      </footer>

      {toast ? (
        <div className="fixed bottom-4 left-1/2 z-50 flex -translate-x-1/2 items-center gap-3 rounded-full bg-fg px-4 py-2 text-sm font-semibold text-chrome shadow-xl">
          <span>{toast}</span>
          <Link to="/cart" className="text-lavender-hi underline">
            View cart
          </Link>
        </div>
      ) : null}
    </div>
  );
}

function FooterCol({ title, links }: { title: string; links: [string, string][] }) {
  return (
    <div>
      <h2 className="text-sm font-semibold">{title}</h2>
      <ul className="mt-3 flex flex-col gap-2">
        {links.map(([href, label]) => (
          <li key={href}>
            <a href={href} className="text-sm text-muted hover:text-fg">
              {label}
            </a>
          </li>
        ))}
      </ul>
    </div>
  );
}
