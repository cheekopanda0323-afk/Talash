import { Link } from "@tanstack/react-router";
import { ShoppingCart } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import type { StoreProduct } from "@/lib/api";
import { formatCents } from "@/lib/format";
import { useCart, useMotion } from "@/lib/store";

function GhostAvatar() {
  return (
    <div className="ghost-avatar" aria-hidden>
      <svg viewBox="0 0 80 80" className="h-full w-full">
        <circle cx="40" cy="40" r="40" fill="#514a64" />
        <circle cx="40" cy="32" r="12" fill="#efeaf8" opacity="0.55" />
        <ellipse cx="40" cy="64" rx="22" ry="14" fill="#efeaf8" opacity="0.38" />
      </svg>
    </div>
  );
}

export function ProductArt({
  product,
  className = "",
  eager = false,
  stage = "shop",
}: {
  product: StoreProduct;
  className?: string;
  eager?: boolean;
  stage?: "shop" | "bare";
}) {
  const animate = useMotion((s) => s.animate);
  const [bg, fg] = product.images;
  const loading = eager ? "eager" : "lazy";
  const [failed, setFailed] = useState(false);
  const [near, setNear] = useState(stage === "bare");
  const rootRef = useRef<HTMLDivElement>(null);
  const motion = product.motion_url;
  const play = animate && Boolean(motion) && !failed && (stage === "bare" || near);
  const showGhost = stage === "shop" && product.type === 0 && !fg;

  useEffect(() => {
    setFailed(false);
  }, [product.sku_id, animate]);

  useEffect(() => {
    if (stage === "bare" || !animate) return;
    const node = rootRef.current;
    if (!node) return;
    const observer = new IntersectionObserver(([entry]) => setNear(entry?.isIntersecting ?? false), {
      rootMargin: "180px",
    });
    observer.observe(node);
    return () => observer.disconnect();
  }, [animate, stage]);

  return (
    <div ref={rootRef} className={`card-art relative overflow-hidden ${className}`}>
      {showGhost ? <GhostAvatar /> : null}
      {fg ? (
        <>
          <img
            src={bg}
            alt=""
            aria-hidden
            loading={loading}
            decoding="async"
            referrerPolicy="no-referrer"
            className="absolute inset-0 h-full w-full object-cover opacity-90"
          />
          <img
            src={fg}
            alt={product.name}
            loading={loading}
            decoding="async"
            referrerPolicy="no-referrer"
            className="absolute inset-0 h-full w-full object-contain"
          />
        </>
      ) : play && product.motion_kind === "video" && motion ? (
        <video
          src={motion}
          poster={bg}
          autoPlay
          loop
          muted
          playsInline
          onError={() => setFailed(true)}
          className="absolute inset-0 h-full w-full object-contain p-2"
        />
      ) : play && motion && product.type === 1 ? (
        <>
          <img
            src={bg}
            alt=""
            aria-hidden
            loading={loading}
            decoding="async"
            referrerPolicy="no-referrer"
            className={`absolute inset-0 h-full w-full object-contain ${stage === "bare" ? "p-6" : "p-2"}`}
          />
          <img
            src={motion}
            alt={product.name}
            loading={loading}
            decoding="async"
            referrerPolicy="no-referrer"
            onError={() => setFailed(true)}
            className={`absolute inset-0 h-full w-full object-contain ${stage === "bare" ? "p-6" : "p-2"}`}
          />
        </>
      ) : bg || (play && motion) ? (
        <img
          src={play && motion ? motion : bg}
          alt={product.name}
          loading={loading}
          decoding="async"
          referrerPolicy="no-referrer"
          onError={() => {
            if (play) setFailed(true);
          }}
          className={`absolute inset-0 h-full w-full object-contain ${stage === "bare" ? "p-8" : "p-2"}`}
        />
      ) : null}
    </div>
  );
}

export function ProductCard({ product, eager = false }: { product: StoreProduct; eager?: boolean }) {
  const add = useCart((s) => s.add);
  const price = formatCents(product.price_cents, product.currency);
  const compare =
    product.compare_at_cents != null && product.compare_at_cents > product.price_cents
      ? formatCents(product.compare_at_cents, product.currency)
      : null;

  return (
    <div className="group/card relative min-w-0 transition-transform duration-150 hover:-translate-y-0.5">
      <Link to="/p/$slug" params={{ slug: product.sku_id }} className="card group flex h-full flex-col overflow-hidden">
        <ProductArt product={product} eager={eager} stage="shop" className="aspect-art" />
        {product.is_new ? (
          <span className="absolute top-2.5 left-2.5 rounded-full bg-fg px-2.5 py-1 text-xs font-bold text-chrome">
            New
          </span>
        ) : null}
        <div className="flex flex-col gap-1.5 px-3.5 pt-3 pb-3.5">
          <h3 className="truncate text-base leading-tight font-semibold">{product.name}</h3>
          <span className="text-sm text-muted">{product.type_label}</span>
          <div className="mt-0.5 flex flex-wrap items-center gap-x-2 gap-y-1">
            <span className="text-lg font-bold tabular-nums">{price}</span>
            {compare ? <s className="text-sm text-muted tabular-nums">{compare}</s> : null}
            {product.save_percent != null && product.save_percent > 0 ? (
              <span className="pill-save ml-auto">Save {product.save_percent}%</span>
            ) : null}
          </div>
          {!product.available ? <p className="text-xs text-muted">Currently unavailable</p> : null}
        </div>
      </Link>
      {product.available ? (
        <div className="pointer-events-none absolute inset-x-0 top-0 z-10 flex aspect-art items-end p-2.5 opacity-100 transition-opacity sm:opacity-0 sm:group-hover/card:opacity-100 sm:group-focus-within/card:opacity-100">
          <button
            type="button"
            aria-label={`Add ${product.name} to cart`}
            className="pointer-events-auto flex h-10 w-full items-center justify-center gap-2 rounded-xl bg-lavender text-sm font-semibold text-white hover:bg-lavender-hi"
            onClick={() => add(product.sku_id, product.name)}
          >
            <ShoppingCart className="size-4" aria-hidden />
            Add to cart
          </button>
        </div>
      ) : null}
    </div>
  );
}
