import type { ReactNode } from "react";

export function Prose({
  kicker,
  title,
  lede,
  children,
}: {
  kicker?: string;
  title: string;
  lede?: string;
  children: ReactNode;
}) {
  return (
    <article className="wrap max-w-3xl py-10">
      {kicker ? <p className="text-sm font-semibold text-lavender-text">{kicker}</p> : null}
      <h1 className="display mt-1 text-4xl sm:text-5xl">{title}</h1>
      {lede ? <p className="mt-3 text-lg text-soft">{lede}</p> : null}
      <div className="mt-8 flex flex-col gap-8">{children}</div>
    </article>
  );
}

export function Block({ title, children }: { title: string; children: ReactNode }) {
  return (
    <section className="flex flex-col gap-2">
      <h2 className="text-xl font-semibold">{title}</h2>
      <div className="text-soft leading-relaxed">{children}</div>
    </section>
  );
}
