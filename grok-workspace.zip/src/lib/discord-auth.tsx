import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from "react";
import { discordLoginUrl, fetchMe, logoutSession, type ApiUser } from "./api";

type AuthState = {
  user: ApiUser | null;
  loading: boolean;
  error: string | null;
  refresh: () => Promise<void>;
  login: () => void;
  logout: () => Promise<void>;
};

const DiscordAuthContext = createContext<AuthState | null>(null);

export function DiscordAuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<ApiUser | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const refresh = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      setUser(await fetchMe());
    } catch (err) {
      setUser(null);
      setError(err instanceof Error ? err.message : "Failed to load session");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void refresh();
  }, [refresh]);

  const login = useCallback(() => {
    window.location.assign(discordLoginUrl());
  }, []);

  const logout = useCallback(async () => {
    try {
      await logoutSession();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Logout failed");
    } finally {
      setUser(null);
    }
  }, []);

  const value = useMemo(
    () => ({ user, loading, error, refresh, login, logout }),
    [user, loading, error, refresh, login, logout],
  );

  return <DiscordAuthContext.Provider value={value}>{children}</DiscordAuthContext.Provider>;
}

export function useDiscordAuth() {
  const ctx = useContext(DiscordAuthContext);
  if (!ctx) throw new Error("useDiscordAuth must be used within DiscordAuthProvider");
  return ctx;
}
