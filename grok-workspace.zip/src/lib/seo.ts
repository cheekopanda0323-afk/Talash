export function pageMeta(title: string, description: string, index = true) {
  const meta: Array<{ title: string } | { name: string; content: string }> = [
    { title },
    { name: "description", content: description },
  ];
  if (!index) meta.push({ name: "robots", content: "noindex" });
  return { meta };
}

export function titleFromSlug(slug: string) {
  const cleaned = slug.replace(/-(avatar-decoration|profile-effect|nameplate|profile-frame|bundle)$/i, "");
  return cleaned
    .split("-")
    .filter(Boolean)
    .map((part) => part.charAt(0).toUpperCase() + part.slice(1))
    .join(" ");
}
