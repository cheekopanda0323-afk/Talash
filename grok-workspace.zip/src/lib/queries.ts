import { keepPreviousData, useQueries, useQuery, useQueryClient } from "@tanstack/react-query";
import { useEffect, useRef } from "react";
import {
  fetchBalance,
  fetchBalanceHistory,
  fetchCatalog,
  fetchCatalogItem,
  fetchCollections,
  fetchDeposit,
  fetchHealth,
  fetchOrders,
  fetchQueue,
  fetchStats,
  type CatalogQuery,
} from "./api";
import { useDiscordAuth } from "./discord-auth";

export function useCatalog(query: CatalogQuery, enabled = true) {
  return useQuery({
    queryKey: ["catalog", query],
    queryFn: () => fetchCatalog(query),
    enabled,
    placeholderData: keepPreviousData,
    staleTime: 30_000,
  });
}

export function useCatalogItem(skuId: string) {
  return useQuery({
    queryKey: ["catalog", "item", skuId],
    queryFn: () => fetchCatalogItem(skuId),
    enabled: Boolean(skuId),
    staleTime: 60_000,
  });
}

export function useProducts(skuIds: string[]) {
  return useQueries({
    queries: skuIds.map((skuId) => ({
      queryKey: ["catalog", "item", skuId],
      queryFn: () => fetchCatalogItem(skuId),
      staleTime: 60_000,
    })),
  });
}

export function useCollections() {
  return useQuery({
    queryKey: ["collections"],
    queryFn: fetchCollections,
    staleTime: 60_000,
  });
}

export function useBalance() {
  const { user } = useDiscordAuth();
  return useQuery({
    queryKey: ["balance"],
    queryFn: fetchBalance,
    enabled: Boolean(user),
    staleTime: 15_000,
  });
}

export function useLedger(page = 1) {
  const { user } = useDiscordAuth();
  return useQuery({
    queryKey: ["ledger", page],
    queryFn: () => fetchBalanceHistory(page),
    enabled: Boolean(user),
  });
}

export function useOrders(page = 1) {
  const { user } = useDiscordAuth();
  return useQuery({
    queryKey: ["orders", page],
    queryFn: () => fetchOrders({ page, limit: 20 }),
    enabled: Boolean(user),
  });
}

export function useDeposit(id: string | null) {
  return useQuery({
    queryKey: ["deposit", id],
    queryFn: () => fetchDeposit(id as string),
    enabled: Boolean(id),
    refetchInterval: (query) => {
      const status = query.state.data?.status;
      if (!status) return 4000;
      if (/expire|cancel|fail|credit|paid|success|complete|confirmed/i.test(status) && !/await|pending|confirming/i.test(status)) {
        return false;
      }
      return 4000;
    },
  });
}

export function useQueue() {
  return useQuery({
    queryKey: ["queue"],
    queryFn: fetchQueue,
    staleTime: 15_000,
    refetchInterval: 30_000,
    retry: false,
  });
}

export function useHealth() {
  return useQuery({
    queryKey: ["health"],
    queryFn: fetchHealth,
    staleTime: 20_000,
    retry: 1,
  });
}

export function useStats() {
  return useQuery({
    queryKey: ["stats"],
    queryFn: fetchStats,
    staleTime: 20_000,
    retry: false,
  });
}

/** Drop private caches when the Discord session disappears. */
export function SessionCacheReset() {
  const { user, loading } = useDiscordAuth();
  const client = useQueryClient();
  const prev = useRef<string | null | undefined>(undefined);

  useEffect(() => {
    if (loading) return;
    const id = user?.id ?? null;
    if (prev.current && !id) {
      client.removeQueries({ queryKey: ["balance"] });
      client.removeQueries({ queryKey: ["ledger"] });
      client.removeQueries({ queryKey: ["orders"] });
      client.removeQueries({ queryKey: ["deposit"] });
    }
    prev.current = id;
  }, [user, loading, client]);

  return null;
}
