import { create } from "zustand";
import { createJSONStorage, persist } from "zustand/middleware";

export type CartLine = { sku_id: string; qty: number };

type MemoryStorage = {
  getItem: (name: string) => string | null;
  setItem: (name: string, value: string) => void;
  removeItem: (name: string) => void;
};

const memory: MemoryStorage = {
  getItem: () => null,
  setItem: () => {},
  removeItem: () => {},
};

function storage() {
  if (typeof window === "undefined") return memory;
  return localStorage;
}

type CartState = {
  lines: CartLine[];
  toast: string | null;
  add: (skuId: string, name?: string) => void;
  remove: (skuId: string) => void;
  clear: () => void;
  dismiss: () => void;
};

export const useCart = create<CartState>()(
  persist(
    (set, get) => ({
      lines: [],
      toast: null,
      add: (skuId, name) => {
        const lines = get().lines.map((line) => ({ ...line }));
        const found = lines.find((line) => line.sku_id === skuId);
        if (found) found.qty = 1;
        else lines.push({ sku_id: skuId, qty: 1 });
        set({ lines, toast: name ? `Added ${name}` : "Added to cart" });
      },
      remove: (skuId) => set({ lines: get().lines.filter((line) => line.sku_id !== skuId) }),
      clear: () => set({ lines: [] }),
      dismiss: () => set({ toast: null }),
    }),
    {
      name: "talash-cart-sku",
      storage: createJSONStorage(storage),
      partialize: (state) => ({ lines: state.lines }),
      skipHydration: true,
    },
  ),
);

type MotionState = {
  animate: boolean;
  toggle: () => void;
};

export const useMotion = create<MotionState>()(
  persist(
    (set, get) => ({
      animate: false,
      toggle: () => set({ animate: !get().animate }),
    }),
    {
      name: "talash-motion",
      storage: createJSONStorage(storage),
      skipHydration: true,
    },
  ),
);

export function cartCount(lines: CartLine[]) {
  return lines.reduce((n, line) => n + line.qty, 0);
}

export function cartSkuIds(lines: CartLine[]) {
  return [...new Set(lines.map((line) => line.sku_id).filter(Boolean))];
}
