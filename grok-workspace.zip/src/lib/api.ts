/**
 * Talash store API client.
 * Every request sends credentials so the HttpOnly talash_session cookie is included.
 * Prices are display-only. Orders send sku ids and a pay method — never a client total.
 */

import { formatCents } from "./format";

export const STORE_ORIGIN = (import.meta.env.VITE_API_BASE || "https://api.talash.store").replace(/\/$/, "");

/** Direct API on talash.store (cookie + CORS). Same-origin proxy everywhere else so the preview can read the catalog. */
export function apiBase() {
  if (typeof window === "undefined") return STORE_ORIGIN;
  const host = window.location.hostname;
  if (host === "talash.store" || host.endsWith(".talash.store")) return STORE_ORIGIN;
  return "/api/store";
}

export const API_BASE = STORE_ORIGIN;

export const TYPE_LABELS: Record<number, string> = {
  0: "Avatar Decoration",
  1: "Profile Effect",
  2: "Nameplate",
  3: "Profile Frame",
  1000: "Bundle",
};

export const TYPE_TABS = [
  { id: "all", label: "All", type: undefined },
  { id: "0", label: "Avatar", type: 0 },
  { id: "1", label: "Effects", type: 1 },
  { id: "2", label: "Nameplates", type: 2 },
  { id: "3", label: "Frames", type: 3 },
  { id: "1000", label: "Bundles", type: 1000 },
] as const;

export type PayWith = "balance" | "ltc";

export type CatalogSort = "name" | "price_asc" | "price_desc" | "newest";

export type CatalogQuery = {
  type?: number | string;
  collection?: string;
  q?: string;
  sort?: CatalogSort;
  new?: boolean | number | string;
  page?: number;
  limit?: number;
};

export type StoreProduct = {
  sku_id: string;
  name: string;
  type: number;
  type_label: string;
  category: string | null;
  collection_slug: string | null;
  collection_name: string | null;
  images: string[];
  image_url: string;
  motion_url: string | null;
  motion_kind: "image" | "video" | null;
  price_cents: number;
  compare_at_cents: number | null;
  save_percent: number | null;
  is_new: boolean;
  available: boolean;
  availability: string;
  currency: string;
};

export type StoreCollection = {
  slug: string;
  name: string;
  count: number;
  banner: string | null;
};

export type CatalogPage = {
  products: StoreProduct[];
  total: number;
  page: number;
  limit: number;
  pages: number;
  currency: string;
  source: "catalog" | "products";
};

export type ApiUser = {
  id: string;
  username: string;
  global_name?: string | null;
  avatar?: string | null;
};

export type Balance = {
  balance_cents: number;
  balance: string;
  currency: string;
};

export type LedgerEntry = {
  id: string;
  type: string;
  amount_cents: number;
  created_at?: string;
  note?: string;
  balance_after_cents?: number;
};

export type Deposit = {
  deposit_id: string;
  status: string;
  address?: string;
  amount_ltc?: string;
  payment_uri?: string;
  expires_at?: string;
  amount_cents?: number;
  currency?: string;
};

export type ApiPayment = {
  address?: string;
  amount_ltc?: string;
  payment_uri?: string;
  expires_at?: string;
  status?: string;
  confirmations?: number;
  received_sat?: number;
  paid_at?: string | null;
};

export type ApiOrderItem = {
  sku_id: string;
  name: string;
  status?: string;
  queue_position?: number;
  image_url?: string;
};

export type ApiOrder = {
  order_id: string;
  status: string;
  pay_with?: string;
  total_cents?: number;
  currency?: string;
  items: ApiOrderItem[];
  payment?: ApiPayment | null;
  queue_position?: number;
  created_at?: string;
};

export type GiftLink = {
  sku_id?: string;
  name?: string;
  url: string;
};

export type HealthInfo = {
  ok: boolean;
  service?: string;
  discord_ready?: boolean;
  payments_ready?: boolean;
  catalog_items?: number;
  time?: number;
};

export type QueueInfo = {
  depth: number;
  label: string;
};

export type StatsInfo = {
  orders?: number;
  delivered?: number;
  catalog_items?: number;
  queue?: number;
  raw: Record<string, unknown>;
};

export class ApiError extends Error {
  status: number;
  code?: string;
  body: unknown;

  constructor(status: number, message: string, body?: unknown, code?: string) {
    super(message);
    this.name = "ApiError";
    this.status = status;
    this.body = body;
    this.code = code;
  }
}

type Obj = Record<string, unknown>;

function isObj(value: unknown): value is Obj {
  return Boolean(value) && typeof value === "object" && !Array.isArray(value);
}

function str(value: unknown): string | null {
  if (typeof value === "string" && value.trim()) return value.trim();
  if (typeof value === "number" && Number.isFinite(value)) return String(value);
  return null;
}

function num(value: unknown): number | null {
  if (typeof value === "number" && Number.isFinite(value)) return value;
  if (typeof value === "string" && value.trim() && Number.isFinite(Number(value))) return Number(value);
  return null;
}

export function slugify(value: string) {
  return value
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-|-$/g, "");
}

function dollarsToCents(value: unknown): number | null {
  if (typeof value === "number" && Number.isFinite(value)) return Math.round(value * 100);
  if (typeof value === "string") {
    const n = Number(value.replace(/[^0-9.]/g, ""));
    if (!Number.isFinite(n)) return null;
    return Math.round(n * 100);
  }
  return null;
}

/** compare_at may arrive as dollars (8.99) or cents (899). */
function looseCents(value: unknown): number | null {
  if (typeof value === "string") return dollarsToCents(value);
  if (typeof value !== "number" || !Number.isFinite(value)) return null;
  if (!Number.isInteger(value)) return Math.round(value * 100);
  if (value >= 100) return Math.round(value);
  return Math.round(value * 100);
}

function extractList(data: unknown): unknown[] {
  if (Array.isArray(data)) return data;
  if (!isObj(data)) return [];
  for (const key of [
    "products",
    "items",
    "results",
    "catalog",
    "collections",
    "orders",
    "entries",
    "history",
    "ledger",
    "deposits",
    "links",
    "gifts",
    "data",
  ]) {
    const value = data[key];
    if (Array.isArray(value)) return value;
  }
  return [];
}

function typeFromLabel(label: string | null): number | null {
  if (!label) return null;
  const s = label.toLowerCase();
  if (s.includes("bundle")) return 1000;
  if (s.includes("nameplate")) return 2;
  if (s.includes("frame")) return 3;
  if (s.includes("effect")) return 1;
  if (s.includes("avatar") || s.includes("deco")) return 0;
  return null;
}

function motionKind(url: string | null): "image" | "video" | null {
  if (!url) return null;
  if (/\.(webm|mp4)(\?|$)/i.test(url)) return "video";
  return "image";
}

function pushUrl(list: string[], value: unknown) {
  const url = str(value);
  if (url && !list.includes(url)) list.push(url);
}

function collectImages(o: Obj): string[] {
  const images: string[] = [];
  const bag = o.images;
  if (Array.isArray(bag)) {
    for (const entry of bag) {
      if (typeof entry === "string") pushUrl(images, entry);
      else if (isObj(entry)) pushUrl(images, entry.url ?? entry.src ?? entry.static);
    }
  } else if (isObj(bag)) {
    pushUrl(images, bag.background ?? bag.bg ?? bag.static);
    pushUrl(images, bag.foreground ?? bag.fg);
    pushUrl(images, bag.image ?? bag.url);
  }
  pushUrl(images, o.image_url);
  pushUrl(images, o.image);
  pushUrl(images, o.thumbnail);
  pushUrl(images, o.static_url);
  return images;
}

export function normalizeProduct(raw: unknown, currency = "USD"): StoreProduct {
  const o = isObj(raw) ? raw : {};
  const nested = isObj(o.product) ? o.product : null;
  const src = nested ?? o;
  const sku = str(src.sku_id) || str(src.sku) || str(src.id) || "";
  const label = str(src.type_label) || str(src.typeLabel);
  const type = num(src.type) ?? typeFromLabel(label) ?? 0;
  const typeLabel = label || TYPE_LABELS[type] || "Item";
  const category = str(src.category);
  const collectionRaw = src.collection;
  const collectionObj = isObj(collectionRaw) ? collectionRaw : null;
  const collectionName =
    (collectionObj ? str(collectionObj.name) || str(collectionObj.title) : null) ||
    (typeof collectionRaw === "string" ? collectionRaw : null) ||
    category;
  const collectionSlug =
    (collectionObj ? str(collectionObj.slug) : null) ||
    str(src.collection_slug) ||
    (collectionName ? slugify(collectionName) : null);

  const images = collectImages(src);
  const motion = str(src.motion_url) || str(src.animated_url) || str(src.motion);
  const priceCents = num(src.price_cents) ?? dollarsToCents(src.price) ?? 0;
  const compare =
    num(src.compare_at_cents) ??
    num(src.compareAtCents) ??
    looseCents(src.compare_at ?? src.compareAt ?? src.list_price ?? src.list_price_cents);
  const save =
    num(src.save_percent) ??
    num(src.save) ??
    (compare != null && compare > priceCents ? Math.max(0, Math.round((1 - priceCents / compare) * 100)) : null);
  const availability = str(src.availability) || "";
  const available = !(
    src.available === false ||
    src.in_stock === false ||
    src.purchasable === false ||
    /unavail|sold.?out|out of stock/i.test(availability)
  );

  return {
    sku_id: sku,
    name: str(src.name) || "Decoration",
    type,
    type_label: typeLabel,
    category,
    collection_slug: collectionSlug,
    collection_name: collectionName,
    images,
    image_url: images[0] || "",
    motion_url: motion,
    motion_kind: motionKind(motion),
    price_cents: priceCents,
    compare_at_cents: compare,
    save_percent: save,
    is_new: Boolean(src.is_new ?? src.isNew ?? src.new),
    available,
    availability: availability || (available ? "available" : "unavailable"),
    currency: str(src.currency) || currency,
  };
}

function normalizeCollection(raw: unknown): StoreCollection | null {
  if (!isObj(raw)) return null;
  const name = str(raw.name) || str(raw.title) || str(raw.label);
  if (!name) return null;
  const slug = str(raw.slug) || slugify(name);
  const banner = str(raw.banner) || str(raw.image_url) || str(raw.image) || null;
  const count = num(raw.count) ?? num(raw.item_count) ?? num(raw.products) ?? 0;
  return { slug, name, count, banner };
}

function normalizePayment(raw: unknown): ApiPayment | null {
  if (!isObj(raw)) return null;
  const address = str(raw.address) || undefined;
  const amount = str(raw.amount_ltc) || (num(raw.amount_ltc) != null ? String(raw.amount_ltc) : undefined);
  const uri = str(raw.payment_uri) || str(raw.uri) || undefined;
  if (!address && !amount && !uri && raw.confirmations == null) return null;
  return {
    address,
    amount_ltc: amount,
    payment_uri: uri,
    expires_at: str(raw.expires_at) || undefined,
    status: str(raw.status) || undefined,
    confirmations: num(raw.confirmations) ?? undefined,
    received_sat: num(raw.received_sat) ?? undefined,
    paid_at: str(raw.paid_at),
  };
}

export function normalizeOrder(raw: unknown): ApiOrder {
  const o = isObj(raw) ? (isObj(raw.order) ? raw.order : raw) : {};
  const itemsRaw = Array.isArray(o.items) ? o.items : [];
  const items: ApiOrderItem[] = itemsRaw.map((item) => {
    const row = isObj(item) ? item : {};
    return {
      sku_id: str(row.sku_id) || str(row.sku) || "",
      name: str(row.name) || "Item",
      status: str(row.status) || undefined,
      queue_position: num(row.queue_position) ?? num(row.position) ?? undefined,
      image_url: str(row.image_url) || str(row.image) || undefined,
    };
  });
  const queue =
    num(o.queue_position) ??
    num(o.position) ??
    (Array.isArray(o.queue_positions) ? num(isObj(o.queue_positions[0]) ? o.queue_positions[0].position : null) : null);
  return {
    order_id: str(o.order_id) || str(o.id) || "",
    status: str(o.status) || "unknown",
    pay_with: str(o.pay_with) || undefined,
    total_cents: num(o.total_cents) ?? dollarsToCents(o.total) ?? undefined,
    currency: str(o.currency) || "USD",
    items,
    payment: normalizePayment(o.payment) || normalizePayment(o.invoice),
    queue_position: queue ?? undefined,
    created_at: str(o.created_at) || str(o.created) || undefined,
  };
}

export function normalizeDeposit(raw: unknown): Deposit {
  const o = isObj(raw) ? (isObj(raw.deposit) ? raw.deposit : raw) : {};
  return {
    deposit_id: str(o.deposit_id) || str(o.id) || "",
    status: str(o.status) || "pending",
    address: str(o.address) || undefined,
    amount_ltc: str(o.amount_ltc) || (num(o.amount_ltc) != null ? String(o.amount_ltc) : undefined),
    payment_uri: str(o.payment_uri) || str(o.uri) || undefined,
    expires_at: str(o.expires_at) || undefined,
    amount_cents: num(o.amount_cents) ?? dollarsToCents(o.amount) ?? undefined,
    currency: str(o.currency) || undefined,
  };
}

export function depositPhase(status: string): "pending" | "credited" | "failed" {
  const s = status.toLowerCase();
  if (/expire|cancel|fail/.test(s)) return "failed";
  if (/(credited|paid|success|completed|complete)/.test(s) || s === "confirmed") return "credited";
  return "pending";
}

function normalizeLedger(raw: unknown, index: number): LedgerEntry {
  const o = isObj(raw) ? raw : {};
  const cents =
    num(o.amount_cents) ??
    num(o.delta_cents) ??
    dollarsToCents(o.amount) ??
    0;
  return {
    id: str(o.id) || str(o.entry_id) || `${str(o.created_at) || "row"}-${index}`,
    type: str(o.type) || str(o.kind) || str(o.reason) || "entry",
    amount_cents: cents,
    created_at: str(o.created_at) || str(o.at) || str(o.time) || undefined,
    note: str(o.note) || str(o.description) || str(o.memo) || undefined,
    balance_after_cents: num(o.balance_after_cents) ?? num(o.balance_cents) ?? undefined,
  };
}

export function normalizeDelivery(data: unknown): GiftLink[] {
  const links: GiftLink[] = [];
  const push = (url: string | null, extra?: Obj) => {
    if (!url || links.some((link) => link.url === url)) return;
    links.push({
      url,
      sku_id: extra ? str(extra.sku_id) || undefined : undefined,
      name: extra ? str(extra.name) || undefined : undefined,
    });
  };
  if (typeof data === "string") push(data);
  for (const item of extractList(data)) {
    if (typeof item === "string") push(item);
    else if (isObj(item)) push(str(item.url) || str(item.gift_url) || str(item.link) || str(item.gift_link), item);
  }
  if (isObj(data)) {
    push(str(data.url) || str(data.gift_url) || str(data.link));
  }
  return links;
}

function pageMeta(data: unknown, fallbackCount: number, query: CatalogQuery) {
  const o = isObj(data) ? data : {};
  const limit = num(o.limit) ?? query.limit ?? (fallbackCount || 40);
  const page = num(o.page) ?? query.page ?? 1;
  const total = num(o.total) ?? num(o.count) ?? fallbackCount;
  const pages = num(o.pages) ?? Math.max(1, Math.ceil(total / Math.max(1, limit)));
  return { page, limit, total, pages, currency: str(o.currency) || "USD" };
}

async function parseJson(res: Response): Promise<unknown> {
  const text = await res.text();
  if (!text) return null;
  try {
    return JSON.parse(text);
  } catch {
    return text;
  }
}

function errorMessage(status: number, body: unknown): { message: string; code?: string } {
  const code = isObj(body) ? str(body.code) || undefined : undefined;
  const apiMessage =
    (isObj(body) && (str(body.error) || str(body.message))) || null;
  if (status === 402 || code === "insufficient_balance" || code === "insufficient_funds") {
    return { message: "Insufficient balance", code };
  }
  if (apiMessage) return { message: apiMessage, code };
  switch (status) {
    case 401:
      return { message: "Please log in with Discord to continue.", code };
    case 403:
      return { message: "You do not have access to that.", code };
    case 404:
      return { message: "Not found.", code };
    case 429:
      return { message: "Too many requests. Wait a moment and try again.", code };
    case 502:
    case 503:
      return { message: "The store is temporarily unavailable. Please try again in a moment.", code };
    case 400:
      return { message: "That request was rejected. Check the details and try again.", code };
    default:
      return { message: status ? `Request failed (${status}). Please try again.` : "Unable to reach the store.", code };
  }
}

export function newIdempotencyKey() {
  if (typeof crypto !== "undefined" && typeof crypto.randomUUID === "function") return crypto.randomUUID();
  return `idem-${Date.now()}-${Math.random().toString(16).slice(2)}`;
}

export async function apiFetch<T = unknown>(path: string, init: RequestInit = {}): Promise<T> {
  const base = apiBase();
  const url = path.startsWith("http") ? path : `${base}${path.startsWith("/") ? "" : "/"}${path}`;
  const headers = new Headers(init.headers);
  if (init.body && !headers.has("Content-Type")) headers.set("Content-Type", "application/json");
  let res: Response;
  try {
    res = await fetch(url, { ...init, credentials: "include", headers });
  } catch (err) {
    throw new ApiError(0, "Unable to reach the store. Check your connection and try again.", err);
  }
  const body = await parseJson(res);
  if (!res.ok) {
    const parsed = errorMessage(res.status, body);
    throw new ApiError(res.status, parsed.message, body, parsed.code);
  }
  return body as T;
}

function catalogQueryString(query: CatalogQuery) {
  const params = new URLSearchParams();
  if (query.type != null && query.type !== "" && query.type !== "all") params.set("type", String(query.type));
  if (query.collection) params.set("collection", query.collection);
  if (query.q) params.set("q", query.q);
  if (query.sort) params.set("sort", query.sort);
  if (query.new === true || query.new === 1 || query.new === "1") params.set("new", "1");
  if (query.page) params.set("page", String(query.page));
  if (query.limit) params.set("limit", String(query.limit));
  const qs = params.toString();
  return qs ? `?${qs}` : "";
}

const FALLBACK_STATUSES = new Set([404, 405, 501]);

let catalogSupported: boolean | null = null;
let productsCache: Promise<StoreProduct[]> | null = null;

async function loadProductList(): Promise<StoreProduct[]> {
  if (!productsCache) {
    productsCache = apiFetch<unknown>("/api/products")
      .then((data) => {
        const currency = isObj(data) ? str(data.currency) || "USD" : "USD";
        return extractList(data)
          .map((row) => normalizeProduct(row, currency))
          .filter((product) => product.sku_id);
      })
      .catch((err) => {
        productsCache = null;
        throw err;
      });
  }
  return productsCache;
}

function matchesQuery(product: StoreProduct, query: CatalogQuery) {
  if (query.type != null && query.type !== "" && query.type !== "all" && product.type !== Number(query.type)) {
    return false;
  }
  if (query.collection) {
    const wanted = query.collection.toLowerCase();
    const slug = product.collection_slug?.toLowerCase();
    const name = product.collection_name?.toLowerCase();
    if (slug !== wanted && name !== wanted && !name?.includes(wanted)) return false;
  }
  if (query.new === true || query.new === 1 || query.new === "1") {
    if (!product.is_new) return false;
  }
  if (query.q) {
    const q = query.q.toLowerCase();
    const hay = [product.name, product.type_label, product.collection_name, product.category, product.sku_id]
      .filter(Boolean)
      .join(" ")
      .toLowerCase();
    if (!hay.includes(q)) return false;
  }
  return true;
}

function sortProducts(products: StoreProduct[], sort?: CatalogSort) {
  const copy = products.slice();
  if (sort === "name") copy.sort((a, b) => a.name.localeCompare(b.name));
  else if (sort === "price_asc") copy.sort((a, b) => a.price_cents - b.price_cents || a.name.localeCompare(b.name));
  else if (sort === "price_desc") copy.sort((a, b) => b.price_cents - a.price_cents || a.name.localeCompare(b.name));
  else if (sort === "newest") copy.sort((a, b) => Number(b.is_new) - Number(a.is_new));
  return copy;
}

function pageFromList(products: StoreProduct[], query: CatalogQuery, currency: string): CatalogPage {
  const limit = query.limit && query.limit > 0 ? query.limit : 40;
  const page = query.page && query.page > 0 ? query.page : 1;
  const sorted = sortProducts(products, query.sort);
  const start = (page - 1) * limit;
  return {
    products: sorted.slice(start, start + limit),
    total: sorted.length,
    page,
    limit,
    pages: Math.max(1, Math.ceil(sorted.length / limit)),
    currency,
    source: "products",
  };
}

function parseCatalogPayload(data: unknown, query: CatalogQuery): CatalogPage {
  const currency = isObj(data) ? str(data.currency) || "USD" : "USD";
  const products = extractList(data)
    .map((row) => normalizeProduct(row, currency))
    .filter((product) => product.sku_id);
  const pagedByServer = isObj(data) && (num(data.page) != null || num(data.pages) != null || num(data.limit) != null);
  if (!pagedByServer) {
    return pageFromList(products.filter((product) => matchesQuery(product, query)), query, currency);
  }
  const meta = pageMeta(data, products.length, query);
  return { products, ...meta, currency: meta.currency || currency, source: "catalog" };
}

export async function fetchCatalog(query: CatalogQuery = {}): Promise<CatalogPage> {
  if (catalogSupported !== false) {
    try {
      const data = await apiFetch<unknown>(`/api/catalog${catalogQueryString(query)}`);
      catalogSupported = true;
      return parseCatalogPayload(data, query);
    } catch (err) {
      if (!(err instanceof ApiError) || !FALLBACK_STATUSES.has(err.status)) throw err;
      catalogSupported = false;
    }
  }
  const all = await loadProductList();
  const currency = all[0]?.currency || "USD";
  return pageFromList(all.filter((product) => matchesQuery(product, query)), query, currency);
}

export async function fetchCatalogItem(skuId: string): Promise<StoreProduct> {
  if (catalogSupported !== false) {
    try {
      const data = await apiFetch<unknown>(`/api/catalog/${encodeURIComponent(skuId)}`);
      catalogSupported = true;
      const row = isObj(data) && (data.product || data.item) ? (data.product ?? data.item) : data;
      const product = normalizeProduct(row);
      if (!product.sku_id) throw new ApiError(404, "Item not found.", data);
      return product;
    } catch (err) {
      if (err instanceof ApiError && FALLBACK_STATUSES.has(err.status)) catalogSupported = false;
      else throw err;
    }
  }
  const all = await loadProductList();
  const found = all.find((product) => product.sku_id === skuId);
  if (!found) throw new ApiError(404, "Item not found.");
  return found;
}

export async function fetchCollections(): Promise<StoreCollection[]> {
  try {
    const data = await apiFetch<unknown>("/api/collections");
    const list = extractList(data).map(normalizeCollection).filter((row): row is StoreCollection => Boolean(row));
    if (list.length) return list;
  } catch (err) {
    if (!(err instanceof ApiError) || !FALLBACK_STATUSES.has(err.status)) throw err;
  }
  const products = await loadProductList();
  const counts = new Map<string, StoreCollection>();
  for (const product of products) {
    if (!product.collection_slug || !product.collection_name) continue;
    const current = counts.get(product.collection_slug);
    if (current) current.count += 1;
    else {
      counts.set(product.collection_slug, {
        slug: product.collection_slug,
        name: product.collection_name,
        count: 1,
        banner: product.image_url || null,
      });
    }
  }
  return [...counts.values()].sort((a, b) => b.count - a.count || a.name.localeCompare(b.name));
}

export async function fetchProducts() {
  const products = await loadProductList();
  return { products, currency: products[0]?.currency || "USD", count: products.length };
}

export async function fetchHealth(): Promise<HealthInfo> {
  const data = await apiFetch<unknown>("/api/health");
  const o = isObj(data) ? data : {};
  return {
    ok: o.ok !== false,
    service: str(o.service) || undefined,
    discord_ready: typeof o.discord_ready === "boolean" ? o.discord_ready : undefined,
    payments_ready: typeof o.payments_ready === "boolean" ? o.payments_ready : undefined,
    catalog_items: num(o.catalog_items) ?? undefined,
    time: num(o.time) ?? undefined,
  };
}

export async function fetchPrices(): Promise<unknown> {
  return apiFetch("/api/prices");
}

export async function fetchStats(): Promise<StatsInfo> {
  const data = await apiFetch<unknown>("/api/stats");
  const o = isObj(data) ? data : {};
  return {
    orders: num(o.orders) ?? num(o.order_count) ?? undefined,
    delivered: num(o.delivered) ?? num(o.completed) ?? undefined,
    catalog_items: num(o.catalog_items) ?? num(o.products) ?? undefined,
    queue: num(o.queue) ?? num(o.queue_depth) ?? undefined,
    raw: o,
  };
}

export async function fetchQueue(): Promise<QueueInfo> {
  const data = await apiFetch<unknown>("/api/queue");
  if (typeof data === "number") {
    return { depth: data, label: data === 0 ? "Queue clear" : `${data} waiting` };
  }
  const o = isObj(data) ? data : {};
  if (o.supported === false) {
    throw new ApiError(404, "Queue is not available.", data);
  }
  const depth =
    num(o.depth) ?? num(o.waiting) ?? num(o.pending) ?? num(o.length) ?? num(o.queue) ?? num(o.count) ?? 0;
  return { depth, label: depth === 0 ? "Queue clear" : `${depth} waiting` };
}

export function discordLoginUrl() {
  return `${STORE_ORIGIN}/auth/discord`;
}

export function discordAvatarUrl(user: ApiUser, size = 64) {
  if (!user.avatar) return null;
  if (user.avatar.startsWith("http")) return user.avatar;
  const ext = user.avatar.startsWith("a_") ? "gif" : "png";
  return `https://cdn.discordapp.com/avatars/${user.id}/${user.avatar}.${ext}?size=${size}`;
}

export function displayName(user: ApiUser) {
  return user.global_name || user.username;
}

export async function fetchMe(): Promise<ApiUser | null> {
  try {
    const data = await apiFetch<unknown>("/api/me");
    const user = isObj(data) ? (isObj(data.user) ? data.user : data) : null;
    if (!user) return null;
    const id = str(user.id);
    const username = str(user.username);
    if (!id || !username) return null;
    return {
      id,
      username,
      global_name: str(user.global_name),
      avatar: str(user.avatar),
    };
  } catch (err) {
    if (err instanceof ApiError && err.status === 401) return null;
    throw err;
  }
}

export async function logoutSession() {
  try {
    await apiFetch("/auth/logout", { method: "POST" });
  } catch (err) {
    if (err instanceof ApiError && (err.status === 401 || err.status === 404 || err.status === 405)) return;
    throw err;
  }
}

export async function fetchBalance(): Promise<Balance> {
  const data = await apiFetch<unknown>("/api/balance");
  const o = isObj(data) ? data : {};
  const cents = num(o.balance_cents) ?? dollarsToCents(o.balance) ?? 0;
  const currency = str(o.currency) || "USD";
  return {
    balance_cents: cents,
    balance: str(o.balance) || formatCents(cents, currency),
    currency,
  };
}

export async function fetchBalanceHistory(page = 1): Promise<{ entries: LedgerEntry[]; page: number }> {
  const data = await apiFetch<unknown>(`/api/balance/history?page=${encodeURIComponent(String(page))}`);
  const entries = extractList(data).map(normalizeLedger);
  return { entries, page: isObj(data) ? num(data.page) ?? page : page };
}

export async function createTopup(amount: number | string, idempotencyKey?: string): Promise<Deposit> {
  const data = await apiFetch<unknown>("/api/balance/topup", {
    method: "POST",
    headers: { "Idempotency-Key": idempotencyKey || newIdempotencyKey() },
    body: JSON.stringify({ amount }),
  });
  return normalizeDeposit(data);
}

export async function fetchDeposits(): Promise<Deposit[]> {
  const data = await apiFetch<unknown>("/api/deposits");
  return extractList(data).map(normalizeDeposit).filter((row) => row.deposit_id);
}

export async function fetchDeposit(id: string): Promise<Deposit> {
  const data = await apiFetch<unknown>(`/api/deposits/${encodeURIComponent(id)}`);
  return normalizeDeposit(data);
}

export async function createOrder(input: {
  sku_ids: string[];
  pay_with: PayWith;
  idempotencyKey?: string;
}): Promise<ApiOrder> {
  const data = await apiFetch<unknown>("/api/orders", {
    method: "POST",
    headers: { "Idempotency-Key": input.idempotencyKey || newIdempotencyKey() },
    body: JSON.stringify({ sku_ids: input.sku_ids, pay_with: input.pay_with }),
  });
  return normalizeOrder(data);
}

export async function fetchOrders(query?: { page?: number; limit?: number }): Promise<{
  orders: ApiOrder[];
  page: number;
  pages: number;
}> {
  const params = new URLSearchParams();
  if (query?.page) params.set("page", String(query.page));
  if (query?.limit) params.set("limit", String(query.limit));
  const qs = params.toString();
  const data = await apiFetch<unknown>(`/api/orders${qs ? `?${qs}` : ""}`);
  const orders = extractList(data).map(normalizeOrder).filter((order) => order.order_id);
  const page = isObj(data) ? num(data.page) ?? query?.page ?? 1 : 1;
  const pages = isObj(data) ? num(data.pages) ?? 1 : 1;
  return { orders, page, pages };
}

export async function fetchOrder(orderId: string): Promise<ApiOrder> {
  const data = await apiFetch<unknown>(`/api/orders/${encodeURIComponent(orderId)}`);
  const order = normalizeOrder(data);
  if (!order.order_id) order.order_id = orderId;
  return order;
}

export async function fetchInvoice(orderId: string): Promise<ApiPayment | null> {
  const data = await apiFetch<unknown>(`/api/orders/${encodeURIComponent(orderId)}/invoice`);
  if (isObj(data) && data.payment) return normalizePayment(data.payment);
  return normalizePayment(data) || normalizeOrder(data).payment || null;
}

export async function fetchDelivery(orderId: string): Promise<GiftLink[]> {
  const data = await apiFetch<unknown>(`/api/orders/${encodeURIComponent(orderId)}/delivery`);
  return normalizeDelivery(data);
}

export async function cancelOrder(orderId: string): Promise<ApiOrder> {
  const data = await apiFetch<unknown>(`/api/orders/${encodeURIComponent(orderId)}/cancel`, { method: "POST" });
  const order = normalizeOrder(data);
  if (!order.order_id) order.order_id = orderId;
  if (!isObj(data) || !str((isObj(data.order) ? data.order : data).status)) order.status = "cancelled";
  return order;
}

export function receiptUrl(orderId: string) {
  return `${API_BASE}/api/orders/${encodeURIComponent(orderId)}/receipt?format=text`;
}

export async function downloadReceipt(orderId: string) {
  const res = await fetch(receiptUrl(orderId), { credentials: "include" });
  const body = await parseJson(res);
  if (!res.ok) {
    const parsed = errorMessage(res.status, body);
    throw new ApiError(res.status, parsed.message, body, parsed.code);
  }
  const text = typeof body === "string" ? body : JSON.stringify(body, null, 2);
  const blob = new Blob([text], { type: "text/plain" });
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = `talash-receipt-${orderId}.txt`;
  document.body.appendChild(anchor);
  anchor.click();
  anchor.remove();
  URL.revokeObjectURL(url);
}
