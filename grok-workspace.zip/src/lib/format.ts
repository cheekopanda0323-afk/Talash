export function formatCents(cents: number, currency = "USD") {
  const amount = cents / 100;
  try {
    return amount.toLocaleString("en-US", { style: "currency", currency });
  } catch {
    return amount.toLocaleString("en-US", { style: "currency", currency: "USD" });
  }
}

export function formatWhen(value?: string | null) {
  if (!value) return "—";
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return value;
  return date.toLocaleString();
}

export function formatCountdown(ms: number) {
  const s = Math.max(0, Math.floor(ms / 1000));
  const m = Math.floor(s / 60);
  const h = Math.floor(m / 60);
  const mm = m % 60;
  const ss = s % 60;
  if (h > 0) return `${h}h ${mm}m ${ss}s`;
  return `${mm}m ${ss}s`;
}

export function orderStatusView(status: string): { label: string; className: string; step: number } {
  const s = status.toLowerCase();
  if (s === "awaiting_payment" || s === "pending" || s === "unpaid") {
    return { label: "Awaiting payment", className: "status-pending", step: 0 };
  }
  if (s === "confirming" || s === "confirmations" || s === "paid") {
    return { label: "Confirming", className: "status-pending", step: 1 };
  }
  if (s === "queued" || s === "processing" || s === "buying" || s === "in_progress") {
    return { label: s === "queued" ? "Queued" : "Processing", className: "status-processing", step: 2 };
  }
  if (s === "delivered" || s === "ready" || s === "completed" || s === "complete") {
    return { label: "Completed", className: "status-done", step: 3 };
  }
  if (s === "expired") return { label: "Expired", className: "status-pending", step: -1 };
  if (s === "cancelled" || s === "canceled") return { label: "Cancelled", className: "status-pending", step: -1 };
  if (s === "failed" || s === "refunded") {
    return { label: s === "refunded" ? "Refunded" : "Failed", className: "status-pending", step: -1 };
  }
  return { label: status.replaceAll("_", " "), className: "status-pending", step: 0 };
}

export function isTerminalOrder(status: string) {
  return ["delivered", "ready", "completed", "complete", "expired", "cancelled", "canceled", "failed", "refunded"].includes(
    status.toLowerCase(),
  );
}

export function isCompletedOrder(status: string) {
  return ["delivered", "ready", "completed", "complete"].includes(status.toLowerCase());
}
